import { useCallback, useEffect, useRef, useState } from "react";
import { ImageOff, RefreshCw } from "lucide-react";
import { Spinner } from "@/components/ui";
import { loadPhotoBatch, PHOTO_MODES, type LibraryPhoto, type PhotoMode } from "@/lib/photo-library";

const BATCH = 24;

interface Props {
  /** Called when a photo is chosen. The gallery shows a spinner on the tile until the promise settles. */
  onPick: (photo: LibraryPhoto) => Promise<void>;
  /** Accessible verb for a tile, e.g. "Use as background". */
  actionLabel: string;
  /** Smaller 3-column grid that scrolls inside its own box (used in popovers). */
  compact?: boolean;
}

/** Endless photo grid: more photos load automatically as you scroll. */
export default function PhotoGallery({ onPick, actionLabel, compact = false }: Props) {
  const [mode, setMode] = useState<PhotoMode>("all");
  const [photos, setPhotos] = useState<LibraryPhoto[]>([]);
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");
  const [errorText, setErrorText] = useState("");
  const [broken, setBroken] = useState<Set<string>>(() => new Set());
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [pickError, setPickError] = useState("");
  const cursor = useRef(0);
  const loading = useRef(false);
  const generation = useRef(0);
  const sentinel = useRef<HTMLDivElement>(null);

  const loadMore = useCallback(async () => {
    if (loading.current) return;
    loading.current = true;
    const mine = generation.current;
    setStatus("loading");
    try {
      const batch = await loadPhotoBatch(mode, cursor.current, BATCH);
      if (mine !== generation.current) return;
      cursor.current += batch.length;
      setPhotos(current => [...current, ...batch]);
      setStatus("idle");
    } catch (error) {
      if (mine !== generation.current) return;
      setErrorText(error instanceof Error ? error.message : "Photos could not be loaded.");
      setStatus("error");
    } finally {
      if (mine === generation.current) loading.current = false;
    }
  }, [mode]);

  // (Re)start the endless stream whenever the look changes.
  useEffect(() => {
    generation.current += 1;
    cursor.current = 0;
    loading.current = false;
    setPhotos([]);
    setBroken(new Set());
    setStatus("idle");
    void loadMore();
  }, [loadMore]);

  // Load the next batch when the bottom of the grid scrolls into view (re-armed after every batch).
  useEffect(() => {
    const node = sentinel.current;
    if (!node || status !== "idle" || !photos.length) return;
    if (typeof IntersectionObserver === "undefined") return;
    const observer = new IntersectionObserver(entries => { if (entries.some(entry => entry.isIntersecting)) void loadMore(); }, { rootMargin: "500px 0px" });
    observer.observe(node);
    return () => observer.disconnect();
  }, [photos.length, status, loadMore]);

  async function pick(photo: LibraryPhoto) {
    if (busyKey) return;
    setBusyKey(photo.key);
    setPickError("");
    try { await onPick(photo); }
    catch (error) { setPickError(error instanceof Error ? error.message : "That photo couldn't be used. Please try another."); }
    finally { setBusyKey(null); }
  }

  const visible = photos.filter(photo => !broken.has(photo.key));

  return <div className={`photo-gallery${compact ? " is-compact" : ""}`}>
    <div className="category-track photo-gallery-modes" role="tablist" aria-label="Photo style">
      {PHOTO_MODES.map(item => <button key={item.key} type="button" role="tab" aria-selected={mode === item.key} className={mode === item.key ? "active" : ""} onClick={() => setMode(item.key)}>{item.label}</button>)}
    </div>
    <div className={compact ? "photo-gallery-scroll" : undefined}>
      <div className="photo-gallery-grid" aria-busy={status === "loading"}>
        {visible.map(photo => <button type="button" key={photo.key} className={`photo-tile${busyKey === photo.key ? " is-busy" : ""}`} disabled={!!busyKey && busyKey !== photo.key} aria-label={`${actionLabel}: photo by ${photo.author}`} title={`Photo by ${photo.author}`} onClick={() => void pick(photo)}>
          <img src={photo.thumb} alt="" loading="lazy" decoding="async" onError={() => setBroken(current => new Set(current).add(photo.key))} />
          {busyKey === photo.key && <span className="photo-tile-busy"><Spinner size={22} /></span>}
        </button>)}
        {status === "loading" && Array.from({ length: photos.length ? 6 : 12 }, (_, i) => <span key={`sk-${i}`} className="photo-tile photo-skeleton" aria-hidden="true" />)}
      </div>
      {pickError && <p className="photo-gallery-pick-error" role="alert">{pickError}</p>}
      {status === "error" && <div className="photo-gallery-error" role="alert"><ImageOff size={20} /><p>{errorText}</p><button type="button" className="secondary-button" onClick={() => void loadMore()}><RefreshCw size={13} />Try again</button></div>}
      <div ref={sentinel} className="photo-gallery-sentinel" aria-hidden="true" />
    </div>
    <p className="photo-gallery-credit">Free photos from Unsplash via Lorem Picsum</p>
  </div>;
}
