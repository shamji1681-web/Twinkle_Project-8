import { useEffect, useRef, type ReactNode } from "react";
import { X, CheckCircle2, AlertCircle, LoaderCircle, Sparkles } from "lucide-react";
import { localApi } from "@/lib/local-api";

export function Logo({ compact = false }: { compact?: boolean }) {
  return <span className={`brand-logo ${compact ? "compact" : ""}`}><svg viewBox="0 0 40 40" fill="none" aria-hidden="true"><path d="M20 19C3-1-5 17 16 21C-2 36 17 46 21 25C36 44 46 23 25 19C44 3 24-5 20 19Z" fill="currentColor" /></svg>{!compact && <span>creato<span className="logo-dot">.</span></span>}</span>;
}

export function Spinner({ size = 18 }: { size?: number }) { return <LoaderCircle size={size} className="spinner" />; }

export function Modal({ title, children, onClose, wide = false, className = "" }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const original = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const timeout = setTimeout(() => ref.current?.querySelector<HTMLElement>("input, button, select, textarea, [tabindex='0']")?.focus(), 30);
    function key(event: KeyboardEvent) {
      if (event.key === "Escape") closeRef.current();
      if (event.key === "Tab") {
        const elements = Array.from(ref.current?.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]), select, textarea, a[href], [tabindex="0"]') || []);
        const first = elements[0], last = elements[elements.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    }
    document.addEventListener("keydown", key);
    return () => { clearTimeout(timeout); document.body.style.overflow = overflow; document.removeEventListener("keydown", key); original?.focus(); };
  }, []);
  return <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}><div ref={ref} className={`modal ${wide ? "modal-wide" : ""} ${className}`} role="dialog" aria-modal="true" aria-label={title}><div className="modal-heading"><h2>{title}</h2><button className="icon-button" onClick={onClose} aria-label="Close dialog"><X size={20} /></button></div>{children}</div></div>;
}

export function Toast({ message, error, onClose }: { message: string; error?: boolean; onClose: () => void }) {
  useEffect(() => { const timer = setTimeout(onClose, 4500); return () => clearTimeout(timer); }, [message, onClose]);
  return <div className={`toast ${error ? "toast-error" : ""}`} role={error ? "alert" : "status"}>{error ? <AlertCircle size={19} /> : <CheckCircle2 size={19} />}<span>{message}</span><button onClick={onClose} aria-label="Dismiss notification"><X size={16} /></button></div>;
}

export function EmptyState({ title, description, action }: { title: string; description: string; action?: ReactNode }) {
  return <div className="empty-state"><span className="empty-icon"><Sparkles size={29} /></span><h3>{title}</h3><p>{description}</p>{action}</div>;
}

/** All "API" calls are served in the browser from localStorage — no server required. */
export async function api<T>(url: string, options?: RequestInit): Promise<T> {
  try {
    return await localApi<T>(url, options);
  } catch (error) {
    throw new Error((error as Error).message || "Something went wrong. Please try again.");
  }
}

export const timeAgo = (date: string) => {
  const minutes = Math.max(0, Math.floor((Date.now() - new Date(date).getTime()) / 60000));
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} ${hours === 1 ? "hour" : "hours"} ago`;
  const days = Math.floor(hours / 24);
  return `${days} ${days === 1 ? "day" : "days"} ago`;
};
