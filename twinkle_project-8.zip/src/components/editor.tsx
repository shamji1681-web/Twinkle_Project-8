import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { createPortal } from "react-dom";
import { resolveAsset } from "@/lib/asset-map";
import { eraseFromDrawLayer } from "@/lib/draw-erase";
import { loadAllCustomFonts } from "@/lib/fonts";
import { ArrowLeft, Blend, Check, FolderOpen, ClipboardPaste, Eraser, Lock, Moon, Move, PaintRoller, Save, Sun, Unlock, Wand2, CloudCheck, CloudUpload, Copy, Gem, Image as ImageIcon, Layers, LayoutTemplate, Maximize, Minus, Palette, Pencil, Plus, Presentation, QrCode, Quote, Redo2, RotateCcw, Shapes, Sparkles, Table2, Trash2, Type, Undo2, Upload, X } from "lucide-react";
import { cloneDocument, makeDraw, newId, MAX_LAYERS, templates, transformCase, type TextCase, type DesignDocument, type DesignLayer, type DesignProject, type DesignTemplate, type Workspace } from "@/lib/designs";
import type { CellTextStyle } from "@/lib/cell-typography";
import { exportDesign, readImage } from "@/lib/export";
import DesignCanvas, { outlineBleed, type Guide } from "@/components/design-canvas";
import SelectionBox from "@/components/selection-box";
import GroupSelectionBox from "@/components/group-selection-box";
import RangeControl from "@/components/range-control";
import OpacityControls from "@/components/opacity-controls";
import SizeFields from "@/components/size-fields";
import OpacityFadeOverlay from "@/components/opacity-fade-overlay";
import ContextBar from "@/components/context-bar";
import DownloadMenu from "@/components/download-menu";
import TextEditorOverlay from "@/components/text-editor-overlay";
import TableOverlay from "@/components/table-overlay";
import ObjectToolbar from "@/components/object-toolbar";
import CropOverlay from "@/components/crop-overlay";
import ProjectsPanel from "@/components/projects-panel";
import { applyTableTextStyle, applyTableTextColor, mergeAt, cellsInRect, clearTableCells, mergeCells, mutateTableTrack, resizeTableStructure, setCellText, splitCell, tableSelection, tableSize, type CellRef, type TableAxis } from "@/lib/table";
import { isCurvedText, fitCurvedBox, normalizeCurvedDocument, resizeCurvedText } from "@/lib/text-curve";
import EffectsPanel from "@/components/effects-panel";
import TransparencyIcon from "@/components/transparency-icon";
import { contentBoundedWidth, fitTextBox, wrappedTextHeight } from "@/lib/text-fit";
import { normalizeQRSettings, type QRSettings } from "@/lib/qr";
import { buildAiDesign, type AiDesignBrief } from "@/lib/ai-design";
import { AiCreatePanel, BackgroundPanel, DesignPanel, DrawPanel, IconPanel, LayerPanel, LinePanel, PhotoPanel, QRPanel, QuotePanel, ShapePanel, TablePanel, TemplatePanel, TextPanel, UploadPanel, type Brush, type EditorContext } from "@/components/editor-panels";
import { shiftScriptRanges } from "@/lib/script-text";
import { api, Logo, Modal, Spinner } from "@/components/ui";
import { toggleTheme, useTheme } from "@/lib/theme";

const TOOLS = [
  { id: "design", name: "Design", icon: Presentation, heading: "Your canvas, your size" },
  { id: "projects", name: "Projects", icon: FolderOpen, heading: "Saved in your projects" },
  { id: "template", name: "Templates", icon: LayoutTemplate, heading: "A little inspiration" },
  { id: "text", name: "Text", icon: Type, heading: "Say it your way" },
  { id: "icon", name: "Icon", icon: Sparkles, heading: "Small marks, big meaning" },
  { id: "shape", name: "Shapes", icon: Shapes, heading: "The little details" },
  { id: "line", name: "Lines", icon: Minus, heading: "Lines and dividers" },
  { id: "table", name: "Table", icon: Table2, heading: "Neat rows and columns" },
  { id: "photo", name: "Photos", icon: ImageIcon, heading: "A picture says it all" },
  { id: "uploads", name: "Uploads", icon: Upload, heading: "Made more personal" },
  { id: "draw", name: "Draw", icon: Pencil, heading: "Draw it yourself" },
  { id: "qr", name: "QR-Code", icon: QrCode, heading: "One scan away" },
  { id: "background", name: "Background", icon: Palette, heading: "Set the mood" },
  { id: "quote", name: "Quotes", icon: Quote, heading: "Words worth keeping" },
  { id: "layer", name: "Layers", icon: Layers, heading: "Every element, in order" },
  { id: "ai", name: "AI Create", icon: Wand2, heading: "A design from your brief" },
  { id: "effects", name: "Effects", icon: Wand2, heading: "A little extra polish" },
] as const;

type Tool = typeof TOOLS[number]["id"];

function ThemeToggle() {
  const theme = useTheme();
  return <button className="editor-theme-toggle" aria-label={theme === "dark" ? "Switch to day mode" : "Switch to night mode"} title={theme === "dark" ? "Day mode" : "Night mode"} onClick={toggleTheme}>{theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}</button>;
}

/** Popovers for the canvas toolbar's opacity/position buttons — one shared panel for every element type. */
function CanvasToolbarPopover({ kind, selected, fadeEditingId, onPatch, onEditingChange, onReorder, onDuplicate, onClose }: {
  kind: "opacity" | "position";
  selected: DesignLayer;
  fadeEditingId: string | null;
  onPatch: (updates: Partial<DesignLayer>) => void;
  onEditingChange: (editing: boolean) => void;
  onReorder: (direction: "front" | "back") => void;
  onDuplicate: () => void;
  onClose: () => void;
}) {
  const boxRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ left: Math.max(12, window.innerWidth - 320), top: 112 });
  useEffect(() => {
    function place() {
      const trigger = document.querySelector(`[data-canvas-popover-trigger="${kind}"]`);
      const box = boxRef.current;
      if (!trigger || !box) return;
      const rect = trigger.getBoundingClientRect();
      const width = box.offsetWidth || (kind === "opacity" ? 286 : 220);
      const height = box.offsetHeight || 300;
      const left = Math.max(10, Math.min(rect.right - width, window.innerWidth - width - 10));
      const top = Math.max(64, Math.min(rect.bottom + 8, window.innerHeight - height - 10));
      setPos({ left, top });
    }
    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => { window.removeEventListener("resize", place); window.removeEventListener("scroll", place, true); };
  }, [kind, selected.id]);
  useEffect(() => {
    function away(event: MouseEvent) {
      const target = event.target as HTMLElement;
      if (!target.closest("[data-canvas-popover]") && !target.closest("[data-canvas-popover-trigger]")) onClose();
    }
    function escape(event: KeyboardEvent) {
      if ((event.target as Element).matches?.('input[type="number"]')) return;
      if (event.key === "Escape") { event.preventDefault(); event.stopImmediatePropagation(); onClose(); }
    }
    document.addEventListener("pointerdown", away, true);
    document.addEventListener("keydown", escape, true);
    return () => { document.removeEventListener("pointerdown", away, true); document.removeEventListener("keydown", escape, true); };
  }, [onClose]);
  return createPortal(
    kind === "opacity"
      ? <div ref={boxRef} data-canvas-popover className="context-popover fixed opacity-popover" style={{ left: pos.left, top: pos.top, width: 286, maxHeight: Math.max(150, window.innerHeight - pos.top - 12) }}>
          <OpacityControls key={selected.id} layer={selected} editing={fadeEditingId === selected.id} onPatch={onPatch} onEditingChange={onEditingChange} onClose={onClose} />
        </div>
      : <div ref={boxRef} data-canvas-popover className="context-popover fixed narrow" style={{ left: pos.left, top: pos.top }}>
          <p className="context-popover-title">Position & size</p>
          <div className="context-grid">{(["x", "y", "width", "height"] as const).map(key => <label key={key}><span>{key === "width" ? "W" : key === "height" ? "H" : key.toUpperCase()}</span><input type="number" aria-label={`Element ${key}`} value={Math.round(selected[key])} onChange={event => onPatch({ [key]: Number(event.target.value) })} /></label>)}</div>
          <label className="context-field" style={{ marginTop: 8, width: "100%", justifyContent: "space-between" }} title="Rotation"><span>Rotation</span><span style={{ display: "flex", alignItems: "center", gap: 4 }}><input className="context-input short" type="number" aria-label="Element rotation" min={-360} max={360} value={Math.round(selected.rotation || 0)} onChange={event => onPatch({ rotation: Math.min(360, Math.max(-360, Number(event.target.value))) })} /><span>°</span></span></label>
          <div className="context-row"><button className="context-button" onClick={() => onReorder("front")}><Plus size={13} />Front</button><button className="context-button" onClick={() => onReorder("back")}><ArrowLeft size={13} />Back</button><button className="context-button" onClick={onDuplicate}><Copy size={13} />Duplicate</button></div>
        </div>,
    document.body
  );
}
interface Props { project: DesignProject; workspace: Workspace | null; onClose: () => void; onSaved: (project: DesignProject) => void; onOpenProject?: (project: DesignProject) => void; notify: (message: string, error?: boolean) => void }
const previewPath = (points: { x: number; y: number }[]) => points.length < 2 ? "" : `M${points.map(point => `${point.x.toFixed(1)} ${point.y.toFixed(1)}`).join(" L")}`;

export default function Editor({ project, workspace, onClose, onSaved, onOpenProject, notify }: Props) {
  const [doc, setDoc] = useState(() => normalizeCurvedDocument(cloneDocument(project.content)));
  const [title, setTitle] = useState(project.title);
  const [tool, setTool] = useState<Tool>("design");
  const [showPanel, setShowPanel] = useState(true);
  const [templateSearch, setTemplateSearch] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const previousSelectedId = useRef<string | null>(null);
  const [status, setStatus] = useState<"saved" | "unsaved" | "saving" | "error">("saved");
  const [savedTick, setSavedTick] = useState(0);
  const [zoom, setZoom] = useState(100);
  const [available, setAvailable] = useState({ width: 800, height: 650 });
  const [historyVersion, setHistoryVersion] = useState(0);
  const [closing, setClosing] = useState(false);
  const [replacement, setReplacement] = useState<DesignTemplate | null>(null);
  const [drawMode, setDrawMode] = useState(false);
  const [eraseMode, setEraseMode] = useState(false);
  const [eraseStrength, setEraseStrength] = useState(1);
  const [eraseSize, setEraseSize] = useState(24);
  const [formatPainterMode, setFormatPainterMode] = useState(false);
  const [lastErasedId, setLastErasedId] = useState<string | null>(null);
  const [uploads, setUploads] = useState<string[]>(() => { try { const raw = sessionStorage.getItem("creato-temp-uploads"); const parsed = raw ? JSON.parse(raw) : []; return Array.isArray(parsed) ? parsed.filter((u): u is string => typeof u === "string" && /^data:image\/(png|jpeg|webp);base64,/.test(u)) : []; } catch { return []; } });
  const [brush, setBrush] = useState<Brush>({ color: "#7952e9", size: 5, tool: "pencil" });
  const [styleClipboard, setStyleClipboard] = useState<Partial<DesignLayer> | null>(null);
  const [strokePreview, setStrokePreview] = useState("");
  const [guides, setGuides] = useState<Guide[]>([]);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [selectedCells, setSelectedCells] = useState<CellRef[]>([]);
  const [editingCell, setEditingCell] = useState<CellRef | null>(null);
  const [cellTextMode, setCellTextMode] = useState(false);
  const [tableStyleOpen, setTableStyleOpen] = useState(false);
  const [cropMode, setCropMode] = useState(false);
  const [fadeEditingId, setFadeEditingId] = useState<string | null>(null);
  const [canvasPopover, setCanvasPopover] = useState<null | "opacity" | "position">(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [multiSelect, setMultiSelect] = useState<string[]>([]);
  const [qrBusy, setQrBusy] = useState(false);
  const textInputRef = useRef<HTMLInputElement>(null);
  const editingRef = useRef<string | null>(null);
  const objectClipboardRef = useRef<DesignLayer[]>([]);

  const current = useRef({ doc, title });
  current.current = { doc, title };
  const saved = useRef(JSON.stringify({ doc: project.content, title: project.title }));
  const savePromise = useRef<Promise<DesignProject> | null>(null);
  const past = useRef<DesignDocument[]>([]);
  const future = useRef<DesignDocument[]>([]);
  const interactionStart = useRef<DesignDocument | null>(null);
  const strokes = useRef<{ x: number; y: number }[]>([]);
  const stageRef = useRef<HTMLDivElement>(null);
  const paperRef = useRef<HTMLDivElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const eraserCursorRef = useRef<HTMLDivElement>(null);
  const [eraserPos, setEraserPos] = useState<{ x: number; y: number } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const callbacks = useRef({ onSaved, notify });
  callbacks.current = { onSaved, notify };
  const selected = doc.layers.find(layer => layer.id === selectedId) || null;
  /** Multi-select via Shift+click (with blank-canvas Ctrl+A as whole-canvas select all). */
  const multiSelectedLayers = multiSelect.length > 1 ? doc.layers.filter(l => multiSelect.includes(l.id)) : [];
  /** Ready-to-align mode: when two or more IDs are set, the align keys snap the reference. */
  const multiAnchorCount = multiSelectedLayers.length;
  /** Toggles multi-select via Shift + click. First Shift-click seeds the set with the
   *  currently selected layer, so anchor = first, target = last Shift-clicked. */
  function toggleMultiSelect(id: string) {
    const latest = current.current.doc;
    const layer = latest.layers.find(l => l.id === id);
    if (!layer || layer.hidden || layer.locked) return;
    // Shift+click on a grouped layer toggles the whole group, Canva-style.
    const ids = layer.groupId ? latest.layers.filter(l => l.groupId === layer.groupId).map(l => l.id) : [id];
    const base = multiSelect.length ? [...multiSelect] : (selectedId && selectedId !== id ? [selectedId] : []);
    const allIn = ids.every(i => base.includes(i));
    const next = allIn ? base.filter(i => !ids.includes(i)) : [...base, ...ids.filter(i => !base.includes(i))];
    setMultiSelect(next);
    if (allIn) {
      if (selectedId && !next.includes(selectedId)) setSelectedId(next[next.length - 1] ?? null);
    } else {
      setSelectedId(id);
    }
    if (editingRef.current) stopEditing();
  }

  /** Plain canvas click: a grouped layer selects its whole group (drill with double-click). */
  function handleSelect(id: string | null) {
    if (id !== editingRef.current) stopEditing();
    if (selectedId && selectedId !== id) autoFitDeselectedText(selectedId);
    setSelectedCells([]); setEditingCell(null);
    if (!id) { setMultiSelect([]); setSelectedId(null); setCropMode(false); return; }
    const layer = current.current.doc.layers.find(l => l.id === id);
    if (layer?.groupId) {
      const members = current.current.doc.layers.filter(l => l.groupId === layer.groupId).map(l => l.id);
      setMultiSelect(members);
      setSelectedId(id);
    } else {
      setMultiSelect([]);
      setSelectedId(id);
    }
  }

  /** Double-click a grouped (non-text) layer to edit just that member. */
  function handleDrillDown(id: string) {
    if (id !== editingRef.current) stopEditing();
    setMultiSelect([id]);
    setSelectedId(id);
    notify("Editing one of the group — click elsewhere to select the whole group again.");
  }

  /** Marquee (rubber-band) select: replace, or Shift to add. Group members expand wholly. */
  function handleMarqueeSelect(ids: string[], additive: boolean) {
    stopEditing(); setSelectedCells([]); setEditingCell(null);
    const latest = current.current.doc;
    const expanded: string[] = [];
    for (const id of ids) {
      const layer = latest.layers.find(l => l.id === id);
      if (!layer) continue;
      const group = layer.groupId ? latest.layers.filter(l => l.groupId === layer.groupId).map(l => l.id) : [id];
      for (const m of group) if (!expanded.includes(m)) expanded.push(m);
    }
    if (!expanded.length) {
      if (!additive) { setMultiSelect([]); setSelectedId(null); }
      return;
    }
    if (additive) {
      setMultiSelect(current => {
        const base = current.length ? current : (selectedId ? [selectedId] : []);
        return [...base, ...expanded.filter(id => !base.includes(id))];
      });
      setSelectedId(expanded[expanded.length - 1]);
    } else if (expanded.length === 1) {
      setMultiSelect([]);
      setSelectedId(expanded[0]);
    } else {
      setMultiSelect(expanded);
      setSelectedId(expanded[expanded.length - 1]);
    }
  }

  /** Canvas drag moves the whole multi-set together (locked members stay put). */
  function handleLayerChange(id: string, updates: Partial<DesignLayer>) {
    const latest = current.current.doc;
    if (multiSelect.includes(id) && multiSelect.length >= 2 && (updates.x !== undefined || updates.y !== undefined)) {
      const base = latest.layers.find(l => l.id === id);
      if (!base) return;
      const dx = (updates.x ?? base.x) - base.x;
      const dy = (updates.y ?? base.y) - base.y;
      if (!dx && !dy) return;
      change({
        ...latest,
        layers: latest.layers.map(l => (multiSelect.includes(l.id) && !l.locked ? { ...l, x: l.x + dx, y: l.y + dy } : l)),
      }, false);
      return;
    }
    patchLayer(id, updates, false);
  }

  /** Applies a group-box transform (move / resize / rotate) to many layers at once. */
  function applyGroupTransform(map: Record<string, Partial<DesignLayer>>) {
    const latest = current.current.doc;
    change({
      ...latest,
      layers: latest.layers.map(l => {
        if (!map[l.id]) return l;
        const eraseBase = l.erased?.length && (!l.naturalWidth || !l.naturalHeight)
          ? { naturalWidth: l.naturalWidth || l.width, naturalHeight: l.naturalHeight || l.height }
          : {};
        return { ...l, ...eraseBase, ...map[l.id] };
      }),
    }, false);
  }
  /**
   * Multi-align: every picked layer except the anchor snaps to the anchor's
   * edge/centre. Anchor = first Shift-clicked (multiSelect[0]).
   */
  function alignByKey(mode: "l" | "c" | "r" | "t" | "e" | "b") {
    const latest = current.current.doc;
    const ids = multiSelect.filter(id => latest.layers.some(l => l.id === id));
    if (ids.length < 2) return;
    const anchor = latest.layers.find(l => l.id === ids[0])!;
    const ax = anchor.x + anchor.width / 2, ay = anchor.y + anchor.height / 2;
    let moved = 0;
    const layers = latest.layers.map(l => {
      if (!ids.includes(l.id) || l.id === anchor.id || l.locked) return l;
      moved++;
      const patch: Partial<DesignLayer> = {};
      switch (mode) {
        case "l": patch.x = anchor.x; break;
        case "r": patch.x = Math.round(anchor.x + anchor.width - l.width); break;
        case "c": patch.x = Math.round(ax - l.width / 2); break;
        case "t": patch.y = anchor.y; break;
        case "b": patch.y = Math.round(anchor.y + anchor.height - l.height); break;
        case "e": patch.y = Math.round(ay - l.height / 2); break;
      }
      return { ...l, ...patch };
    });
    if (!moved) return;
    change({ ...latest, layers });
    const what = moved === 1 ? "1 element" : `${moved} elements`;
    notify({
      l: `${what} snapped to the anchor's left.`,
      c: `${what} centred to the anchor horizontally.`,
      r: `${what} snapped to the anchor's right.`,
      t: `${what} snapped to the anchor's top.`,
      e: `${what} centred to the anchor vertically.`,
      b: `${what} snapped to the anchor's bottom.`,
    }[mode]);
  }

  /** Centers the whole multi-selection bounding box on the page (P with 2+ picked). */
  function centerGroupOnPage() {
    const latest = current.current.doc;
    const members = multiSelect.map(id => latest.layers.find(l => l.id === id)).filter(l => l && !l.locked) as DesignLayer[];
    if (members.length < 2) return;
    const minX = Math.min(...members.map(l => l.x));
    const minY = Math.min(...members.map(l => l.y));
    const maxX = Math.max(...members.map(l => l.x + l.width));
    const maxY = Math.max(...members.map(l => l.y + l.height));
    const dx = Math.round((latest.width - (maxX - minX)) / 2 - minX);
    const dy = Math.round((latest.height - (maxY - minY)) / 2 - minY);
    change({
      ...latest,
      layers: latest.layers.map(l => (members.some(m => m.id === l.id) ? { ...l, x: l.x + dx, y: l.y + dy } : l)),
    });
    notify("Group centered on page.");
  }
  const fadeMode = !!(selected?.opacityFade && fadeEditingId === selected.id && !drawMode && !editingId && !cropMode && !selected.hidden && !selected.locked);
  useEffect(() => { setFadeEditingId(null); setTableStyleOpen(false); setCanvasPopover(null); }, [selectedId]);
  /** Canva-style: selecting an element opens the panel that matches it (text → Text panel, image → Photos, …). */
  const previousPanelSelection = useRef<string | null>(null);
  useEffect(() => {
    if (!selectedId || selectedId === previousPanelSelection.current) { previousPanelSelection.current = selectedId; return; }
    previousPanelSelection.current = selectedId;
    const layer = current.current.doc.layers.find(l => l.id === selectedId);
    if (!layer || drawMode) return;
    const panelFor: Partial<Record<DesignLayer["type"], Tool>> = {
      text: "text",
      image: layer.qr ? "qr" : "photo",
      table: "table",
      icon: "icon",
      shape: "shape",
      rect: "shape",
      ellipse: "shape",
      star: "shape",
      flower: "shape",
      line: "line",
      stroke: "line",
      draw: "draw",
      pattern: "background",
    };
    const next = panelFor[layer.type];
    if (!next) return;
    setTool(next);
    // Phones use the panel as a bottom sheet over the canvas; keep it closed there so the canvas stays usable.
    if (window.innerWidth > 640) setShowPanel(true);
  }, [selectedId, drawMode]);
  const hovered = hoveredId && hoveredId !== selectedId ? doc.layers.find(layer => layer.id === hoveredId) || null : null;
  useEffect(() => { setSelectedCells([]); setEditingCell(null); setCellTextMode(false); if (selected?.type !== "image") setCropMode(false); }, [selectedId]);
  useEffect(() => {
    // Multi-select trail: Shift + click on the canvas builds a move as one multi-group.
    if (!selectedId) setMultiSelect(m => (m.length > 1 ? [] : m));
  }, [selectedId, doc]);
  const editing = editingId ? doc.layers.find(layer => layer.id === editingId) || null : null;
  editingRef.current = editingId;
  const proActive = !!workspace?.trialStartedAt && Date.now() - new Date(workspace.trialStartedAt).getTime() < 14 * 86400000;
  const activeTool = TOOLS.find(item => item.id === tool)!;

  const save = useCallback(async function persist(): Promise<boolean> {
    if (savePromise.current) {
      try { await savePromise.current; } catch { return false; }
      await new Promise(resolve => setTimeout(resolve, 0));
      return persist();
    }
    const snapshot = { doc: current.current.doc, title: current.current.title.trim() || "Untitled design" };
    const key = JSON.stringify(snapshot);
    if (key === saved.current) return true;
    setStatus("saving");
    const promise = api<DesignProject>(`/api/designs/${project.id}`, { method: "PATCH", body: JSON.stringify({ title: snapshot.title, content: snapshot.doc }) });
    savePromise.current = promise;
    try {
      const updated = await promise;
      saved.current = key;
      setSavedTick(tick => tick + 1);
      callbacks.current.onSaved(updated);
      setStatus(JSON.stringify({ doc: current.current.doc, title: current.current.title.trim() || "Untitled design" }) === key ? "saved" : "unsaved");
      return true;
    } catch (error) { setStatus("error"); callbacks.current.notify((error as Error).message, true); return false; }
    finally { savePromise.current = null; }
  }, [project.id]);

  /** Stores the current canvas as a brand-new project, leaving the original untouched. */
  const saveCopy = useCallback(async (): Promise<DesignProject | null> => {
    const snapshot = { doc: current.current.doc, title: `${(current.current.title.trim() || "Untitled design").slice(0, 110)} (copy)` };
    try {
      const created = await api<DesignProject>("/api/designs", { method: "POST", body: JSON.stringify({ title: snapshot.title, category: project.category, content: snapshot.doc }) });
      setSavedTick(tick => tick + 1);
      callbacks.current.onSaved(created);
      return created;
    } catch (error) { callbacks.current.notify((error as Error).message, true); return null; }
  }, [project.category]);

  /** The toolbar Save button: writes the design and shows it in the Projects panel. */
  const saveToProjects = useCallback(async () => {
    const ok = await save();
    if (!ok) return false;
    setTool("projects");
    setShowPanel(true);
    callbacks.current.notify("Design saved — find it in the Projects panel.");
    return true;
  }, [save]);

  useEffect(() => {
    if (JSON.stringify({ doc, title: title.trim() || "Untitled design" }) === saved.current) return;
    setStatus("unsaved");
    const timer = setTimeout(() => void save(), 900);
    return () => clearTimeout(timer);
  }, [doc, title, save]);

  /** Automatically adjusts a text box on deselect:
   * 1. If width was pulled wider than the text actually occupies, snap width back to
   *    snugly fit the longest line (no empty whitespace on the side).
   * 2. If width was narrowed (wrapping into more lines), keep the narrow width so
   *    vertical/wrapped text stays in place.
   * 3. Height always snaps to the exact wrapped content height.
   * Top-left anchor is preserved so the text never jumps on canvas. */
  function autoFitDeselectedText(layerId: string) {
    const latest = current.current.doc;
    const layer = latest.layers.find(item => item.id === layerId);
    if (!layer || layer.type !== "text" || isCurvedText(layer)) return;
    const align = layer.align || "left";
    const isJustify = align === "justify" || align === "justify-all";

    // If width was manually pulled wider than the text actually needs, snap width down
    // to the actual content width (unless justify, which needs the full frame).
    let targetWidth = layer.width;
    if (!isJustify) {
      const naturalWidth = contentBoundedWidth(layer);
      if (layer.width > naturalWidth + 2) {
        targetWidth = naturalWidth;
      }
    }

    const neededHeight = wrappedTextHeight({ ...layer, width: targetWidth, autoFit: false }, targetWidth);
    const widthDiff = Math.abs(layer.width - targetWidth);
    const heightDiff = Math.abs(layer.height - neededHeight);
    if (widthDiff < 1 && heightDiff < 1) return;

    const radians = ((layer.rotation || 0) * Math.PI) / 180;
    const oldCenterX = layer.x + layer.width / 2;
    const oldCenterY = layer.y + layer.height / 2;
    // Align-aware anchor keeps the text pinned in place:
    // left aligned: top-left pinned; center aligned: top-center pinned; right aligned: top-right pinned.
    const anchorLocalX = align === "center" ? 0 : align === "right" ? layer.width / 2 : -layer.width / 2;
    const anchorLocalY = -layer.height / 2;
    const cos = Math.cos(radians), sin = Math.sin(radians);
    const anchorX = oldCenterX + anchorLocalX * cos - anchorLocalY * sin;
    const anchorY = oldCenterY + anchorLocalX * sin + anchorLocalY * cos;

    const newAnchorLocalX = align === "center" ? 0 : align === "right" ? targetWidth / 2 : -targetWidth / 2;
    const newAnchorLocalY = -neededHeight / 2;
    const newCenterX = anchorX - (newAnchorLocalX * cos - newAnchorLocalY * sin);
    const newCenterY = anchorY - (newAnchorLocalX * sin + newAnchorLocalY * cos);
    const newX = Math.round(newCenterX - targetWidth / 2);
    const newY = Math.round(newCenterY - neededHeight / 2);

    change({
      ...latest,
      layers: latest.layers.map(item => item.id === layerId ? {
        ...item,
        width: targetWidth,
        height: neededHeight,
        x: newX,
        y: newY,
      } : item),
    }, false);
  }

  // Auto-fit text height on deselect: if user stretched the height from bottom-center handle or elsewhere,
  // snap height back to snugly fit the text as soon as the element is deselected.
  useEffect(() => {
    // If format painter is active and user selects a different element:
    if (formatPainterMode && styleClipboard && selectedId && selectedId !== previousSelectedId.current) {
      const target = doc.layers.find(l => l.id === selectedId);
      if (target) {
        applyStyleToLayer(target, styleClipboard);
        setStyleClipboard(null);
        setFormatPainterMode(false);
        notify("Style applied to " + (target.type === "text" ? "text" : target.type) + "! (1-time paste complete)");
      }
    }
    const prevId = previousSelectedId.current;
    previousSelectedId.current = selectedId;
    if (prevId && prevId !== selectedId) {
      autoFitDeselectedText(prevId);
    }
  }, [selectedId, doc, change]);

  useEffect(() => {
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const stage = stageRef.current;
    const observer = new ResizeObserver(entries => { for (const entry of entries) setAvailable({ width: entry.contentRect.width, height: entry.contentRect.height }); });
    if (stage) observer.observe(stage);
    function warn(event: BeforeUnloadEvent) { if (JSON.stringify({ doc: current.current.doc, title: current.current.title.trim() || "Untitled design" }) !== saved.current) { event.preventDefault(); event.returnValue = ""; } }
    window.addEventListener("beforeunload", warn);
    return () => { observer.disconnect(); document.body.style.overflow = overflow; window.removeEventListener("beforeunload", warn); };
  }, []);

  useEffect(() => { loadAllCustomFonts(); }, []);
  useEffect(() => {
    let active = true;
    const refresh = () => { if (active) { const normalized = normalizeCurvedDocument(current.current.doc); if (normalized !== current.current.doc) { current.current.doc = normalized; setDoc(normalized); } } };
    void document.fonts.ready.then(refresh);
    document.fonts.addEventListener("loadingdone", refresh);
    return () => { active = false; document.fonts.removeEventListener("loadingdone", refresh); };
  }, []);

  function beginInteraction() { interactionStart.current = cloneDocument(current.current.doc); }
  function endInteraction() {
    if (interactionStart.current && JSON.stringify(interactionStart.current) !== JSON.stringify(current.current.doc)) remember(interactionStart.current);
    interactionStart.current = null;
    setGuides([]);
  }
  function remember(before = current.current.doc) { past.current = [...past.current.slice(-49), cloneDocument(before)]; future.current = []; setHistoryVersion(version => version + 1); }
  function change(next: DesignDocument, record = true) { if (record) remember(); const normalized = normalizeCurvedDocument(next); current.current.doc = normalized; setDoc(normalized); }
  /** Keeps a text box wrapped around its words: auto-fit hugs the text, fixed-width reflows and grows in height. */
  function withTextFit(layer: DesignLayer, updates: Partial<DesignLayer>): Partial<DesignLayer> {
    if (layer.type !== "text") return updates;
    // Inline sub/superscript spans follow their words while typing; spans inside
    // the edited region are dropped since those words changed.
    if (updates.text !== undefined && updates.scriptRanges === undefined && layer.scriptRanges?.length) {
      updates = { ...updates, scriptRanges: shiftScriptRanges(layer.text || "", updates.text, layer.scriptRanges) };
    }
    const merged = { ...layer, ...updates };
    const metricKeys: (keyof DesignLayer)[] = ["text", "fontSize", "fontFamily", "fontWeight", "italic", "align", "curve", "letterSpacing", "lineHeight", "wordSpacing", "paraSpacing", "firstLineIndent", "listStyle", "listBulletVariant", "listNumberFormat", "listStart", "paraLevels", "dropCap", "dropCapLines", "dropCapGap", "dropCapFont", "dropCapFill", "script", "scriptRanges", "scriptSize", "scriptShift"];
    const metricsChanged = metricKeys.some(key => updates[key] !== undefined);
    if (isCurvedText(merged)) {
      // All curve resizes change the type size, not an unrelated straight-text rectangle.
      if (updates.fontSize === undefined && (updates.width !== undefined || updates.height !== undefined)) {
        const factor = updates.width !== undefined ? updates.width / layer.width : updates.height! / layer.height;
        return { ...updates, ...resizeCurvedText(layer, factor, 1, 1) };
      }
      if (metricsChanged || updates.width !== undefined || updates.height !== undefined) return { ...updates, ...fitCurvedBox(merged), autoFit: false };
      return updates;
    }
    if (isCurvedText(layer) && updates.curve !== undefined) return { ...updates, ...fitTextBox(merged), autoFit: true, curve: 0 };
    if (updates.width !== undefined || updates.height !== undefined || !metricsChanged) return updates;
    if (layer.autoFit === false) return { ...updates, height: wrappedTextHeight(merged, layer.width) };
    return { ...updates, ...fitTextBox(merged) };
  }
  function patchLayer(id: string, updates: Partial<DesignLayer>, record = true) {
    const latest = current.current.doc;
    change({ ...latest, layers: latest.layers.map(layer => {
      if (layer.id !== id) return layer;
      // Any entry point that changes table dimensions must also remap cells and tracks.
      const resized = layer.type === "table" && (updates.rows !== undefined || updates.cols !== undefined)
        ? resizeTableStructure(layer, updates.rows ?? tableSize(layer).rows, updates.cols ?? tableSize(layer).cols) : {};
      const eraseBase = layer.erased?.length && (!layer.naturalWidth || !layer.naturalHeight) && !("erased" in updates && updates.erased === undefined)
        ? { naturalWidth: layer.naturalWidth || layer.width, naturalHeight: layer.naturalHeight || layer.height }
        : {};
      return { ...layer, ...eraseBase, ...resized, ...withTextFit(layer, updates) };
    }) }, record);
  }
  function fitTextUpdates(id: string): Partial<DesignLayer> {
    const layer = current.current.doc.layers.find(item => item.id === id);
    return layer && layer.type === "text" ? (isCurvedText(layer) ? fitCurvedBox(layer) : fitTextBox(layer)) : {};
  }
  /** Opens in-place typing on a text layer, the way a double-click does in Canva. */
  function startEditing(id: string) {
    setFadeEditingId(null);
    const layer = current.current.doc.layers.find(item => item.id === id);
    if (!layer || layer.type !== "text" || layer.locked || layer.hidden) return;
    setMultiSelect([]);
    setSelectedId(id);
    setEditingId(id);
  }
  /** Leaves in-place typing; an empty box is removed so no invisible layers pile up. */
  function stopEditing() {
    const id = editingRef.current;
    setEditingId(null);
    if (!id) return;
    const layer = current.current.doc.layers.find(item => item.id === id);
    if (layer && layer.type === "text" && !(layer.text || "").trim()) {
      change({ ...current.current.doc, layers: current.current.doc.layers.filter(item => item.id !== id) });
      setSelectedId(null);
    }
  }
  function fitText(id: string) { patchLayer(id, fitTextUpdates(id)); callbacks.current.notify("Text box wrapped around your words."); }

  async function generateQR(settings: QRSettings, mode: "add" | "update", dimension?: number): Promise<boolean> {
    try {
      setQrBusy(true);
      const { dataUrl } = await api<{ dataUrl: string }>("/api/qr", { method: "POST", body: JSON.stringify({ settings }) });
      if (mode === "update" && selectedId) {
        patchLayer(selectedId, { src: dataUrl, qr: normalizeQRSettings(settings) });
        callbacks.current.notify("QR code restyled.");
      } else {
        const size = Math.round(Math.min(current.current.doc.width, current.current.doc.height) * Math.max(.15, Math.min(.7, dimension ?? .3)));
        addLayer({ id: `qr-${Date.now().toString(36)}`, type: "image", x: Math.round((current.current.doc.width - size) / 2), y: Math.round((current.current.doc.height - size) / 2), width: size, height: size, fill: "transparent", src: dataUrl, qr: normalizeQRSettings(settings) });
        callbacks.current.notify("Styled QR code added to your canvas.");
      }
      return true;
    } catch (error) { callbacks.current.notify((error as Error).message, true); return false; }
    finally { setQrBusy(false); }
  }
  async function previewQR(settings: QRSettings): Promise<string | null> {
    try {
      const { dataUrl } = await api<{ dataUrl: string }>("/api/qr", { method: "POST", body: JSON.stringify({ settings }) });
      return dataUrl;
    } catch (error) { callbacks.current.notify((error as Error).message, true); return null; }
  }
  function styleOf(layer: DesignLayer): Partial<DesignLayer> {
    const common: Partial<DesignLayer> = { fill: layer.fill, fillAlpha: layer.fillAlpha, fillGradient: layer.fillGradient, fillImage: layer.fillImage, fillImageZoom: layer.fillImageZoom, fillImageX: layer.fillImageX, fillImageY: layer.fillImageY, opacity: layer.opacity, opacityFade: layer.opacityFade, effects: layer.effects, outline: layer.outline, radius: layer.radius, rotation: layer.rotation };
    if (layer.type === "text") return { ...common, fontSize: layer.fontSize, fontFamily: layer.fontFamily, fontWeight: layer.fontWeight, italic: layer.italic, underline: layer.underline, strikethrough: layer.strikethrough, letterSpacing: layer.letterSpacing, lineHeight: layer.lineHeight, wordSpacing: layer.wordSpacing, firstLineIndent: layer.firstLineIndent, paraSpacing: layer.paraSpacing, align: layer.align, listStyle: layer.listStyle, listBulletVariant: layer.listBulletVariant, listNumberFormat: layer.listNumberFormat, listStart: layer.listStart, paraLevels: layer.paraLevels, dropCap: layer.dropCap, dropCapLines: layer.dropCapLines, dropCapMargin: layer.dropCapMargin, dropCapGap: layer.dropCapGap, dropCapFont: layer.dropCapFont, dropCapFill: layer.dropCapFill, script: layer.script, scriptSize: layer.scriptSize, scriptShift: layer.scriptShift, scriptRanges: layer.scriptRanges, curve: layer.curve, textStrokeColor: layer.textStrokeColor, textStrokeWidth: layer.textStrokeWidth, textFillTransparent: layer.textFillTransparent };
    if (layer.type === "image") return { ...common, cropZoom: layer.cropZoom, cropX: layer.cropX, cropY: layer.cropY, mask: layer.mask };
    if (layer.type === "stroke" || layer.type === "draw") return { ...common, strokeWidth: layer.strokeWidth, variant: layer.variant };
    if (layer.type === "table") return { ...common, lineColor: layer.lineColor, lineWidth: layer.lineWidth, tableLineStyle: layer.tableLineStyle, cellFill: layer.cellFill, headerFill: layer.headerFill };
    return common;
  }
  function applyStyleToLayer(targetLayer: DesignLayer, styleData: Partial<DesignLayer>) {
    const next: Partial<DesignLayer> = JSON.parse(JSON.stringify(styleData));
    const remove = (keys: string[]) => keys.forEach(key => delete (next as Record<string, unknown>)[key]);
    if (targetLayer.type !== "text") remove(["fontSize","fontFamily","fontWeight","italic","underline","strikethrough","letterSpacing","lineHeight","wordSpacing","firstLineIndent","paraSpacing","align","listStyle","listBulletVariant","listNumberFormat","listStart","paraLevels","dropCap","dropCapLines","dropCapMargin","dropCapGap","dropCapFont","dropCapFill","script","scriptSize","scriptShift","scriptRanges","curve","textStrokeColor","textStrokeWidth","textFillTransparent"]);
    if (targetLayer.type !== "image") remove(["cropZoom","cropX","cropY","mask"]);
    if (targetLayer.type !== "stroke" && targetLayer.type !== "draw") remove(["strokeWidth","variant"]);
    if (targetLayer.type !== "table") remove(["lineColor","lineWidth","tableLineStyle","cellFill","headerFill"]);
    patchLayer(targetLayer.id, next);
  }

  function copyStyle() {
    if (!selected) return;
    const styleData = JSON.parse(JSON.stringify(styleOf(selected)));
    setStyleClipboard(styleData);
    setFormatPainterMode(true);
    notify("Copy style active! Now click any other element to paste style (1-time).");
  }

  function pasteStyle() {
    if (!selected || !styleClipboard) return;
    applyStyleToLayer(selected, styleClipboard);
    setStyleClipboard(null);
    setFormatPainterMode(false);
    notify("Style pasted!");
  }
  function fitImageToCanvas() { if (!selected || selected.type !== "image" || selected.qr) return; patchLayer(selected.id, { x: 0, y: 0, width: current.current.doc.width, height: current.current.doc.height, cropZoom: 1, cropX: .5, cropY: .5, radius: 0, mask: undefined }); notify("Image fitted to the canvas."); }
  function eraseDrawAt(point: { x: number; y: number }, recordHistory = true) {
    const radius = Math.max(4, (brush.size || 24) * 0.5);
    const layers = current.current.doc.layers;
    let modified = false;
    const newLayers: DesignLayer[] = [];

    for (const l of layers) {
      if (l.type !== "draw" || l.locked || l.hidden) {
        newLayers.push(l);
        continue;
      }
      const replaced = eraseFromDrawLayer(l, point, radius);
      if (replaced === null) {
        newLayers.push(l);
      } else {
        modified = true;
        newLayers.push(...replaced);
      }
    }

    if (modified) {
      change({ ...current.current.doc, layers: newLayers }, recordHistory);
    }
  }
  /** Erases part of whichever element sits under the pointer — images, shapes, text, drawings. */
  function eraseElementAt(point: { x: number; y: number }, record = false) {
    const radius = Math.max(2, eraseSize / 2);
    const strength = Math.max(0.05, Math.min(1, eraseStrength));
    const layers = current.current.doc.layers;
    for (let index = layers.length - 1; index >= 0; index--) {
      const layer = layers[index];
      if (layer.locked || layer.hidden) continue;
      if (layer.type === "draw") {
        const replaced = eraseFromDrawLayer(layer, point, radius);
        if (replaced === null) continue;
        const next = [...layers.slice(0, index), ...replaced, ...layers.slice(index + 1)];
        change({ ...current.current.doc, layers: next }, record);
        setLastErasedId(replaced[0]?.id ?? null);
        return true;
      }
      // Undo the layer's rotation and flip so the dab lands where the user sees it.
      const cx = layer.x + layer.width / 2, cy = layer.y + layer.height / 2;
      const a = -((layer.rotation || 0) * Math.PI) / 180;
      const dx = point.x - cx, dy = point.y - cy;
      let lx = cx + dx * Math.cos(a) - dy * Math.sin(a) - layer.x;
      let ly = cy + dx * Math.sin(a) + dy * Math.cos(a) - layer.y;
      if (layer.effects?.flipX) lx = layer.width - lx;
      if (layer.effects?.flipY) ly = layer.height - ly;
      if (lx < -radius || ly < -radius || lx > layer.width + radius || ly > layer.height + radius) continue;
      const natW = layer.erased?.length ? (layer.naturalWidth || layer.width) : layer.width;
      const natH = layer.erased?.length ? (layer.naturalHeight || layer.height) : layer.height;
      const scaleX = natW / Math.max(1, layer.width);
      const scaleY = natH / Math.max(1, layer.height);
      const nx = lx * scaleX;
      const ny = ly * scaleY;
      const nr = radius * Math.max(scaleX, scaleY);
      const dabs = [...(layer.erased || [])];
      const last = dabs[dabs.length - 1];
      // Skip dabs that land on top of the previous one so dragging stays cheap.
      if (last && Math.hypot(last[0] - nx, last[1] - ny) < nr * 0.25 && Math.abs(last[2] - nr) < 0.5) return true;
      if (dabs.length >= 3800) return true;
      dabs.push([Math.round(nx * 10) / 10, Math.round(ny * 10) / 10, Math.round(nr * 10) / 10, strength]);
      patchLayer(layer.id, { erased: dabs, naturalWidth: natW, naturalHeight: natH }, record);
      setLastErasedId(layer.id);
      return true;
    }
    return false;
  }
  function clearErase(id: string) {
    patchLayer(id, { erased: undefined, naturalWidth: undefined, naturalHeight: undefined });
    if (lastErasedId === id) setLastErasedId(null);
    notify("Erased areas restored.");
  }
  function addLayer(layer: DesignLayer) {
    if (current.current.doc.layers.length >= MAX_LAYERS) { callbacks.current.notify(`Your canvas has reached ${MAX_LAYERS} elements. Remove one to add another.`, true); return; }
    change({ ...current.current.doc, layers: [...current.current.doc.layers, layer] });
    setMultiSelect([]);
    setSelectedId(layer.id);
  }
  function addLayers(layers: DesignLayer[]) {
    const room = MAX_LAYERS - current.current.doc.layers.length;
    if (room <= 0) { callbacks.current.notify(`Your canvas has reached ${MAX_LAYERS} elements. Remove one to add another.`, true); return; }
    const slice = layers.slice(0, room);
    change({ ...current.current.doc, layers: [...current.current.doc.layers, ...slice] });
    setMultiSelect([]);
    setSelectedId(slice[slice.length - 1]?.id ?? null);
    notify("Quote style added. Every piece stays editable.");
  }
  function removeLayer(id: string) {
    change({ ...current.current.doc, layers: current.current.doc.layers.filter(layer => layer.id !== id) });
    setMultiSelect(m => m.filter(i => i !== id));
    if (selectedId === id) setSelectedId(null);
  }
  function duplicateLayer(id: string) {
    const layer = current.current.doc.layers.find(item => item.id === id);
    if (!layer) return;
    if (current.current.doc.layers.length >= MAX_LAYERS) return callbacks.current.notify(`Your canvas has reached ${MAX_LAYERS} elements.`, true);
    const copy = { ...layer, id: `${layer.id.slice(0, 24)}c${Date.now().toString(36).slice(-4)}`, x: layer.x + 24, y: layer.y + 24 };
    change({ ...current.current.doc, layers: [...current.current.doc.layers, copy] });
    setMultiSelect([]);
    setSelectedId(copy.id);
  }
  /** Moves a layer to an absolute stack position (0 = back). Used by drag-and-drop in the Layers panel. */
  function moveLayer(id: string, toIndex: number) {
    const layers = [...current.current.doc.layers];
    const index = layers.findIndex(layer => layer.id === id);
    if (index < 0) return;
    const target = Math.max(0, Math.min(layers.length - 1, toIndex));
    if (target === index) return;
    const [layer] = layers.splice(index, 1);
    layers.splice(target, 0, layer);
    change({ ...current.current.doc, layers });
  }
  function reorder(id: string, direction: "front" | "back" | "up" | "down") {
    const layers = [...current.current.doc.layers];
    const index = layers.findIndex(layer => layer.id === id);
    if (index < 0) return;
    const [layer] = layers.splice(index, 1);
    const target = direction === "front" ? layers.length : direction === "back" ? 0 : direction === "up" ? Math.min(layers.length, index + 1) : Math.max(0, index - 1);
    layers.splice(target, 0, layer);
    change({ ...current.current.doc, layers });
  }
  /** Layer ids currently managed by a group. */
  function groupMemberIds(groupId?: string | null) {
    if (!groupId) return [] as string[];
    const latest = current.current.doc;
    const layer = latest.layers.find(l => l.id === selectedId);
    const gid = layer?.groupId ?? latest.layers.find(l => l.groupId === groupId)?.groupId;
    if (!gid) return [] as string[];
    return latest.layers.filter(l => l.groupId === gid && !l.groupLocked).map(l => l.id);
  }

  /** Copies the current selection (one layer, or the whole multi-set) to the clipboard. */
  function copySelection() {
    const ids = selectionSet().filter(id => !current.current.doc.layers.find(l => l.id === id)?.groupLocked);
    if (!ids.length) return;
    objectClipboardRef.current = ids.map(id => JSON.parse(JSON.stringify(current.current.doc.layers.find(l => l.id === id)!)) as DesignLayer);
    notify(ids.length > 1 ? `Copied ${ids.length} elements.` : "Copied to clipboard.");
  }

  /** Pastes every clipboard layer as fresh copies, nudged down-right, and selects them. */
  function pasteClipboard() {
    const raws = objectClipboardRef.current;
    if (!raws.length) return;
    const latest = current.current.doc;
    const room = MAX_LAYERS - latest.layers.length;
    if (room <= 0) { callbacks.current.notify(`Your canvas has reached ${MAX_LAYERS} elements. Remove one to add another.`, true); return; }
    const copies = raws.slice(0, room).map(raw => {
      const copy = JSON.parse(JSON.stringify(raw)) as DesignLayer;
      copy.id = newId();
      copy.groupId = undefined;
      copy.groupLocked = false;
      copy.x += 24;
      copy.y += 24;
      return copy;
    });
    change({ ...latest, layers: [...latest.layers, ...copies] });
    setMultiSelect(copies.length > 1 ? copies.map(c => c.id) : []);
    setSelectedId(copies[copies.length - 1].id);
    notify(copies.length > 1 ? `Pasted ${copies.length} elements.` : "Pasted.");
  }

  /** Cut = copy + delete the whole selection. */
  function cutSelection() {
    const latest = current.current.doc;
    const ids = selectionSet().filter(id => {
      const l = latest.layers.find(x => x.id === id);
      return l && !l.locked && !l.groupLocked;
    });
    if (!ids.length) return;
    objectClipboardRef.current = ids.map(id => JSON.parse(JSON.stringify(latest.layers.find(l => l.id === id)!)) as DesignLayer);
    change({ ...latest, layers: latest.layers.filter(l => !ids.includes(l.id)) });
    setMultiSelect([]);
    setSelectedId(null);
    notify(ids.length > 1 ? `Cut ${ids.length} elements.` : "Cut to clipboard.");
  }

  /** Duplicates the whole selection in place. */
  function duplicateSelection() {
    const latest = current.current.doc;
    const ids = selectionSet();
    if (!ids.length) return;
    const room = MAX_LAYERS - latest.layers.length;
    if (room <= 0) { callbacks.current.notify(`Your canvas has reached ${MAX_LAYERS} elements.`, true); return; }
    const copies = ids.slice(0, room).map(id => {
      const layer = latest.layers.find(l => l.id === id)!;
      return { ...JSON.parse(JSON.stringify(layer)) as DesignLayer, id: newId(), groupId: undefined, groupLocked: false, x: layer.x + 24, y: layer.y + 24 };
    });
    change({ ...latest, layers: [...latest.layers, ...copies] });
    setMultiSelect(copies.length > 1 ? copies.map(c => c.id) : []);
    setSelectedId(copies[copies.length - 1].id);
    notify(copies.length > 1 ? `Duplicated ${copies.length} elements.` : "Duplicated.");
  }

  /** Deletes the whole selection (a lone grouped layer removes its entire group). */
  function deleteSelection() {
    const latest = current.current.doc;
    const ids = selectionSet();
    if (!ids.length) return;
    if (ids.length === 1) {
      const layer = latest.layers.find(l => l.id === ids[0]);
      if (layer?.groupId) {
        change({ ...latest, layers: latest.layers.filter(l => l.groupId !== layer.groupId) });
        setMultiSelect([]);
        setSelectedId(null);
        notify("Group deleted.");
        return;
      }
    }
    change({ ...latest, layers: latest.layers.filter(l => !ids.includes(l.id)) });
    setMultiSelect([]);
    setSelectedId(null);
    notify(ids.length > 1 ? `Deleted ${ids.length} elements.` : "Deleted.");
  }

  /** Nudges the whole selection (locked layers stay put). */
  function moveSelection(dx: number, dy: number) {
    const latest = current.current.doc;
    const ids = selectionSet().filter(id => !latest.layers.find(l => l.id === id)?.locked);
    if (!ids.length) return;
    change({
      ...latest,
      layers: latest.layers.map(l => (ids.includes(l.id) ? { ...l, x: l.x + dx, y: l.y + dy } : l)),
    });
  }

  /** Steps the whole selection one layer up/down the stack, order preserved. */
  function reorderSelection(direction: "up" | "down") {
    const latest = current.current.doc;
    const ids = selectionSet();
    if (!ids.length) return;
    const order = latest.layers.map(l => l.id);
    const sorted = [...ids].sort((a, b) => order.indexOf(a) - order.indexOf(b));
    const sequence = direction === "up" ? [...sorted].reverse() : sorted;
    const next = [...latest.layers];
    for (const id of sequence) {
      const at = next.findIndex(l => l.id === id);
      const to = direction === "up" ? Math.min(next.length - 1, at + 1) : Math.max(0, at - 1);
      if (at < 0 || to === at) continue;
      const [moved] = next.splice(at, 1);
      next.splice(to, 0, moved);
    }
    change({ ...latest, layers: next });
    notify(direction === "up" ? "Sent forward one layer." : "Sent back one layer.");
  }

  /** Group: wrap selected ids into a new group (Ctrl+A / Shift+click + G). */
  function groupSelection(ids: string[]) {
    if (ids.length < 2) return;
    const gid = newId();
    const latest = current.current.doc;
    const before = latest.layers.filter(l => ids.includes(l.id) && l.groupId).length;
    change({ ...latest, layers: latest.layers.map(l => ids.includes(l.id) ? { ...l, groupId: gid } : l) });
    // Selection becomes the group, so Ctrl+U right after works and further moves stay together.
    setMultiSelect(ids);
    setSelectedId(ids[ids.length - 1]);
    notify(before ? `Grouped ${ids.length} elements into a new group (Ctrl+U to ungroup).` : `Grouped ${ids.length} elements (Ctrl+U to ungroup).`);
  }

  /** Ungroup: strip group ids from a group's members. */
  function ungroupGroup(groupId: string) {
    const latest = current.current.doc;
    change({ ...latest, layers: latest.layers.map(l => l.groupId === groupId ? { ...l, groupId: undefined } : l) });
    setSelectedId(selectedId);
    notify("Ungrouped.");
  }

  /** Aligns any layer to the page; position snaps to the frame. */
  function alignLayer(id: string, mode: "left" | "centerX" | "centerY" | "right" | "top" | "bottom" | "page") {
    const latest = current.current.doc;
    const layer = latest.layers.find(item => item.id === id);
    if (!layer || layer.locked) return;
    const patch: Partial<DesignLayer> = {};
    if (mode === "left") patch.x = 0;
    else if (mode === "right") patch.x = Math.round(latest.width - layer.width);
    else if (["centerX", "centerY", "page"].includes(mode)) patch.x = Math.round((latest.width - layer.width) / 2);
    if (mode === "top") patch.y = 0;
    else if (mode === "bottom") patch.y = Math.round(latest.height - layer.height);
    else if (["centerY", "page"].includes(mode)) patch.y = Math.round((latest.height - layer.height) / 2);
    patchLayer(id, patch);
    notify({ left: "Aligned left.", centerX: "Centered horizontally.", centerY: "Centered vertically.", right: "Aligned right.", top: "Aligned top.", bottom: "Aligned bottom.", page: "Centered on page." }[mode]);
  }

  /** Select-all: every non-locked, non-hidden layer joins the multi-selection. */
  function selectAllLayers(): string[] {
    const latest = current.current.doc;
    const ids = latest.layers.filter(l => !l.locked && !l.hidden).map(l => l.id);
    if (ids.length) {
      setMultiSelect(ids);
      setSelectedId(ids[ids.length - 1]);
      notify(`${ids.length} elements selected — Ctrl+G groups them, C E L R T B align.`);
    } else {
      setMultiSelect([]);
      setSelectedId(null);
    }
    return ids;
  }

  /** The working set for bulk shortcuts: the multi-set when 2+ are picked, else the single layer. */
  function selectionSet(): string[] {
    const latest = current.current.doc;
    const multi = multiSelect.filter(id => latest.layers.some(l => l.id === id));
    if (multi.length >= 2) return multi;
    return selectedId && latest.layers.some(l => l.id === selectedId) ? [selectedId] : [];
  }
  function currentTable() { const layer = current.current.doc.layers.find(l => l.id === selectedId); return layer?.type === "table" && !layer.locked ? layer : null; }
  function tableInsert(axis: TableAxis, atEnd = false) {
    const layer = currentTable(); if (!layer) return;
    const { rows, cols } = tableSize(layer);
    if ((axis === "row" && rows >= 20) || (axis === "column" && cols >= 12)) return;
    const bounds = tableSelection(layer, selectedCells);
    const position = atEnd || !selectedCells.length ? (axis === "row" ? rows : cols) : (axis === "row" ? bounds.r2 + 1 : bounds.c2 + 1);
    patchLayer(layer.id, mutateTableTrack(layer, axis, "insert", position));
    setSelectedCells([{ r: axis === "row" ? position : Math.min(selectedCells[0]?.r ?? 0, rows - 1), c: axis === "column" ? position : Math.min(selectedCells[0]?.c ?? 0, cols - 1) }]); setEditingCell(null);
  }
  function tableDelete(axis: TableAxis) {
    const layer = currentTable(); if (!layer) return;
    const { rows, cols } = tableSize(layer);
    if ((axis === "row" ? rows : cols) <= 1) return;
    const position = axis === "row" ? selectedCells[0]?.r ?? rows - 1 : selectedCells[0]?.c ?? cols - 1;
    patchLayer(layer.id, mutateTableTrack(layer, axis, "delete", position));
    setSelectedCells([]); setEditingCell(null);
  }
  function tableResize(rows: number, cols: number) {
    const layer = currentTable(); if (!layer) return;
    patchLayer(layer.id, resizeTableStructure(layer, rows, cols)); setSelectedCells([]); setEditingCell(null);
  }
  function tableDistribute(axis: TableAxis) {
    const layer = currentTable(); if (!layer) return;
    const count = axis === "row" ? tableSize(layer).rows : tableSize(layer).cols;
    patchLayer(layer.id, { [axis === "row" ? "rowHeights" : "colWidths"]: Array.from({ length: count }, () => 1 / count) });
  }
  function tableClear() { const layer = currentTable(); if (layer) patchLayer(layer.id, clearTableCells(layer, selectedCells)); }
  function beginCellText(cell?: CellRef) {
    const layer = currentTable(); if (!layer) return;
    endInteraction(); stopEditing(); setTableStyleOpen(false); setFadeEditingId(null);
    if (cell || selectedCells.length <= 1) {
      const chosen = cell || selectedCells[0] || { r: 0, c: 0 };
      const origin = mergeAt(layer, chosen.r, chosen.c);
      const target = origin ? { r: origin.r, c: origin.c } : chosen;
      setSelectedCells([target]); setEditingCell(target);
    }
    setCellTextMode(true);
  }
  function finishCellText() { endInteraction(); setEditingCell(null); setCellTextMode(false); }
  function formatCellText(updates: CellTextStyle & { fill?: string }) {
    const layer = currentTable(); if (!layer) return;
    endInteraction();
    patchLayer(layer.id, { ...applyTableTextStyle(layer, selectedCells, updates), ...(updates.fill !== undefined ? applyTableTextColor(layer, selectedCells, updates.fill) : {}) });
  }
  function changeCellTextCase(mode: TextCase) {
    const layer = currentTable(); if (!layer) return;
    endInteraction();
    const bounds = tableSelection(layer, selectedCells), cols = layer.cols || 1;
    const cells = (layer.cells || []).map((text, i) => Math.floor(i / cols) >= bounds.r1 && Math.floor(i / cols) <= bounds.r2 && i % cols >= bounds.c1 && i % cols <= bounds.c2 ? transformCase(text, mode) : text);
    patchLayer(layer.id, { cells });
  }
  function undo() { const previous = past.current.pop(); if (!previous) return; future.current.push(cloneDocument(current.current.doc)); current.current.doc = previous; setDoc(previous); setMultiSelect([]); setSelectedId(null); setHistoryVersion(version => version + 1); }
  function redo() { const next = future.current.pop(); if (!next) return; past.current.push(cloneDocument(current.current.doc)); current.current.doc = next; setDoc(next); setMultiSelect([]); setSelectedId(null); setHistoryVersion(version => version + 1); }

  const toolbarSelectionRef = useRef({ selectedId, selected, doc, multiSelect } as { selectedId: string | null; selected: DesignLayer | null; doc: DesignDocument; multiSelect: string[] });
  toolbarSelectionRef.current = { selectedId, selected, doc, multiSelect };

  useEffect(() => {
    function keyboard(event: KeyboardEvent) {
      const mod = event.metaKey || event.ctrlKey;
      const key = event.key;
      const lower = key.toLowerCase();
      // While the typing overlay is up, only Escape / Ctrl+Enter may act (they commit text).
      // The textarea itself consumes typical typing through its focused target; body-level
      // dispatch (our shortcuts) still needs this guard for the auto-open state after adding text.
      // The typing overlay is the only active keyboard scene. Canvas-wide shortcuts
      // treat body-targeted key events as if they were voice commands — selection,
      // alignment, clipboard, zoom, layer order. Text layer Ctrl keys are not blocked here.
      if (document.querySelector(".text-edit-overlay") && !mod && ["Delete", "Backspace", "PageUp", "PageDown", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Escape"].includes(key)) return;
      const target = (event.target as HTMLElement | null) ?? document.body;
      if (document.querySelector("[role=dialog]")) return;
      if (target.closest?.("input:not(.design-name-input),textarea,select,[contenteditable='true']")) return;

      const latest = current.current.doc;
      const focused = toolbarSelectionRef.current;
      const singleId = focused.selectedId;
      const single = focused.selected;

      // --- Save & history ---
      if (mod && lower === "s") { event.preventDefault(); void save(); return; }
      if (mod && lower === "z" && !event.shiftKey) { event.preventDefault(); undo(); return; }
      if (mod && (lower === "y" || (lower === "z" && event.shiftKey))) { event.preventDefault(); redo(); return; }

      // --- Clipboard (whole multi-set when 2+ are picked) ---
      if (mod && lower === "a") { event.preventDefault(); selectAllLayers(); return; }
      if (mod && lower === "c") {
        if (single?.type === "text" && document.activeElement && (document.activeElement as HTMLTextAreaElement).selectionStart !== undefined) return; // let text selection copy
        event.preventDefault();
        copySelection();
        return;
      }
      if (mod && lower === "x") { event.preventDefault(); cutSelection(); return; }
      if (mod && lower === "v") { event.preventDefault(); pasteClipboard(); return; }
      if (mod && lower === "d") { event.preventDefault(); duplicateSelection(); return; }

      // --- Group / ungroup (the current multi-set, not the whole canvas) ---
      if (mod && lower === "g") {
        event.preventDefault();
        const existing = multiSelect.filter(id => latest.layers.some(l => l.id === id));
        const ids = existing.length >= 2 ? existing : selectAllLayers();
        if (ids.length >= 2) groupSelection(ids);
        else notify("Select at least 2 elements to group — Shift+click or Ctrl+A.", true);
        return;
      }
      if (mod && lower === "u") {
        event.preventDefault();
        const ids = multiSelect.length >= 2 ? multiSelect : (singleId ? [singleId] : []);
        const gids = [...new Set(ids.map(id => latest.layers.find(l => l.id === id)?.groupId).filter(Boolean))] as string[];
        if (!gids.length) { notify("No group selected.", true); return; }
        gids.forEach(ungroupGroup);
        return;
      }

      // --- Bulk & delete ---
      if ((key === "Delete" || key === "Backspace") && (singleId || multiSelect.length >= 2)) {
        event.preventDefault();
        deleteSelection();
        return;
      }

      // --- Layer stack: Page Up / Page Down ---
      if ((key === "PageUp" || key === "PageDown") && (singleId || multiSelect.length >= 2)) {
        event.preventDefault();
        reorderSelection(key === "PageUp" ? "up" : "down");
        return;
      }

      // --- Arrow-key movement (whole multi-set moves together) ---
      if ((singleId || multiSelect.length >= 2) && [ "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight" ].includes(key)) {
        event.preventDefault();
        const step = event.shiftKey ? 10 : 1;
        moveSelection(key === "ArrowRight" ? step : key === "ArrowLeft" ? -step : 0, key === "ArrowDown" ? step : key === "ArrowUp" ? -step : 0);
        return;
      }

      // --- Object alignment ---
      // 2+ picked (Shift+click / Ctrl+A): the reference snaps to the anchor.
      // Single layer: snaps to the page.
      if (!mod && singleId && ["l", "c", "r", "t", "b", "e", "p"].includes(lower)) {
        event.preventDefault();
        if (lower === "p") {
          if (multiSelect.length >= 2) centerGroupOnPage();
          else alignLayer(singleId, "page");
          return;
        }
        if (multiSelect.length >= 2) alignByKey(lower as "l" | "c" | "r" | "t" | "e" | "b");
        else {
          const modeMap: Record<string, "left" | "centerX" | "centerY" | "right" | "top" | "bottom"> = { l: "left", c: "centerX", r: "right", t: "top", b: "bottom", e: "centerY" };
          alignLayer(singleId, modeMap[lower]);
        }
        return;
      }

      // --- Text-only alignment (Ctrl+L / Ctrl+C / Ctrl+R) for selected text boxes ---
      if (mod && single?.type === "text" && ["l", "c", "r"].includes(lower)) {
        event.preventDefault();
        const alignment = lower === "l" ? ("left" as const) : lower === "c" ? ("center" as const) : ("right" as const);
        patchLayer(single.id, { align: alignment });
        notify(alignment === "left" ? "Text left-aligned." : alignment === "center" ? "Text centered." : "Text right-aligned.");
        return;
      }

      // --- Zoom (eased, like Canva) ---
      if (mod && (key === "-" || key === "_")) { event.preventDefault(); smoothZoomTo(zoomTargetRef.current * 0.9); return; }
      if (mod && (key === "=" || key === "+")) { event.preventDefault(); smoothZoomTo(zoomTargetRef.current / 0.9); return; }

      // --- Misc ---
      if ((event.key === "Enter" || event.key === "F2") && singleId) {
        const layer = current.current.doc.layers.find(item => item.id === singleId);
        if (layer?.type === "text") { event.preventDefault(); startEditing(singleId); return; }
      }
      if (event.key === "Escape") { if (fadeEditingId) { setFadeEditingId(null); return; } if (drawMode) setDrawMode(false); if (selectedId) autoFitDeselectedText(selectedId); setMultiSelect([]); setSelectedId(null); }
    }
    document.addEventListener("keydown", keyboard);
    return () => document.removeEventListener("keydown", keyboard);
  });

  async function addImage(src: string) {
    if (current.current.doc.layers.length >= MAX_LAYERS) throw new Error(`Your canvas has reached ${MAX_LAYERS} elements.`);
    const image = new window.Image();
    image.src = resolveAsset(src);
    await new Promise<void>((resolve, reject) => { image.onload = () => resolve(); image.onerror = () => reject(new Error("This image couldn't be opened.")); });
    const latest = current.current.doc;
    const ratio = Math.min(latest.width * .65 / image.naturalWidth, latest.height * .65 / image.naturalHeight);
    const width = Math.round(image.naturalWidth * ratio), height = Math.round(image.naturalHeight * ratio);
    addLayer({ id: `img-${Date.now().toString(36)}`, type: "image", x: Math.round((latest.width - width) / 2), y: Math.round((latest.height - height) / 2), width, height, fill: "transparent", src });
  }
  async function upload(file?: File) {
    if (!file) return;
    try {
      const src = await readImage(file);
      // Keep the upload in a temporary, session-scoped space until the design is saved.
      setUploads(current => {
        const next = [src, ...current.filter(u => u !== src)].slice(0, 8);
        try { sessionStorage.setItem("creato-temp-uploads", JSON.stringify(next)); } catch { /* Storage full: keep the in-memory copy only. */ }
        return next;
      });
      await addImage(src); notify("Your image is on the canvas — and saved in Your uploads for this session.");
    }
    catch (error) { notify((error as Error).message, true); }
  }
  function applyTemplate(template: DesignTemplate) {
    change(cloneDocument(template.content));
    if (title.startsWith("Untitled")) setTitle(template.title);
    setSelectedId(null); setReplacement(null);
    if (window.innerWidth <= 850) setShowPanel(false);
    notify("A fresh starting point. Everything is editable.");
  }
  function useTemplate(template: DesignTemplate) {
    if (template.pro && !proActive) return notify("This is a Pro template. Start your free trial from Home to unlock it.");
    if (current.current.doc.layers.length) setReplacement(template); else applyTemplate(template);
  }

  function canvasPoint(event: ReactPointerEvent) {
    // Use the surface the pointer is actually on (draw overlay or eraser overlay).
    const surface = (event.currentTarget as HTMLElement) || overlayRef.current;
    const rect = surface?.getBoundingClientRect() || overlayRef.current?.getBoundingClientRect();
    if (!rect || !rect.width) return { x: 0, y: 0 };
    return { x: (event.clientX - rect.left) * doc.width / rect.width, y: (event.clientY - rect.top) * doc.height / rect.height };
  }
  const isErasing = useRef(false);
  const elementErasing = useRef(false);
  const lastElementErasePoint = useRef<{ x: number; y: number } | null>(null);
  function startElementErase(event: ReactPointerEvent) {
    event.preventDefault();
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
    elementErasing.current = true;
    remember();
    const pt = canvasPoint(event);
    lastElementErasePoint.current = pt;
    eraseElementAt(pt);
  }
  function moveElementErase(event: ReactPointerEvent) {
    if (!elementErasing.current) return;
    const pt = canvasPoint(event);
    const prev = lastElementErasePoint.current;
    if (prev) {
      const dist = Math.hypot(pt.x - prev.x, pt.y - prev.y);
      const step = Math.max(2, (eraseSize / 2) * 0.35);
      const steps = Math.min(24, Math.ceil(dist / step));
      for (let i = 1; i <= steps; i++) {
        const t = i / steps;
        eraseElementAt({ x: prev.x + (pt.x - prev.x) * t, y: prev.y + (pt.y - prev.y) * t });
      }
    } else {
      eraseElementAt(pt);
    }
    lastElementErasePoint.current = pt;
  }
  function endElementErase() {
    if (!elementErasing.current) return;
    elementErasing.current = false;
    lastElementErasePoint.current = null;
    notify("Erased. Undo or Restore brings it back.");
  }

  function startStroke(event: ReactPointerEvent) {
    event.preventDefault();
    const point = canvasPoint(event);
    overlayRef.current?.setPointerCapture(event.pointerId);
    if (brush.tool === "eraser") {
      isErasing.current = true;
      remember();
      eraseDrawAt(point, false);
      return;
    }
    strokes.current = [point];
    setStrokePreview("");
  }
  function continueStroke(event: ReactPointerEvent) {
    let point = canvasPoint(event);
    if (brush.tool === "eraser") {
      if (!isErasing.current) return;
      eraseDrawAt(point, false);
      return;
    }
    if (!strokes.current.length) return;
    if (event.shiftKey) {
      // Shift + drag: constrain the new segment to straight 45°-step direction,
      // the same way a marquee guides a straight move.
      const start = strokes.current[0];
      const dx = point.x - start.x, dy = point.y - start.y;
      if (Math.hypot(dx, dy) > 12) {
        const angle = Math.atan2(dy, dx);
        const step = Math.round(angle / (Math.PI / 4)) * (Math.PI / 4);
        const len = Math.hypot(dx, dy);
        point = { x: start.x + Math.cos(step) * len, y: start.y + Math.sin(step) * len };
      } else return;
    }
    const last = strokes.current[strokes.current.length - 1];
    if (Math.hypot(point.x - last.x, point.y - last.y) < 1.5) return;
    strokes.current.push(point);
    setStrokePreview(previewPath(strokes.current));
  }
  function endStroke() {
    if (brush.tool === "eraser") {
      if (isErasing.current) {
        isErasing.current = false;
        notify("Erased.");
      }
      return;
    }
    if (strokes.current.length > 1) {
      const layer = makeDraw(strokes.current, brush.color, brush.size, brush.tool);
      if (layer) addLayer(layer);
    }
    strokes.current = [];
    setStrokePreview("");
  }

  const scale = Math.max(.03, Math.min((available.width - 96) / doc.width, (available.height - 100) / doc.height, 1)) * zoom / 100;

  // Ctrl / Meta + wheel over the canvas stage zooms the design only.
  // Ctrl / Meta + mouse wheel = design-only zoom. A native, non-passive listener on the
  // whole editor shell is required: React's onWheel is passive (preventDefault is ignored),
  // so the browser would zoom the page instead of the canvas.
  const wheelRef = useRef<HTMLDivElement | null>(null);

  // Canva-style smooth zoom: the scale is eased toward a target with requestAnimationFrame,
  // so the canvas and the selection handles glide together (both derive from this value).
  const zoomCurrentRef = useRef(100);
  const zoomTargetRef = useRef(100);
  const zoomRAF = useRef<number | null>(null);
  function smoothZoomTo(target: number) {
    const clamped = Math.min(600, Math.max(25, target));
    zoomTargetRef.current = clamped;
    if (zoomRAF.current) return; // already easing toward the (now updated) target
    const step = () => {
      const current = zoomCurrentRef.current;
      const diff = zoomTargetRef.current - current;
      if (Math.abs(diff) < 0.4) { zoomCurrentRef.current = zoomTargetRef.current; setZoom(zoomTargetRef.current); zoomRAF.current = null; return; }
      zoomCurrentRef.current = current + diff * 0.22;
      setZoom(zoomCurrentRef.current);
      zoomRAF.current = requestAnimationFrame(step);
    };
    zoomRAF.current = requestAnimationFrame(step);
  }
  function setZoomDirect(value: number) {
    const clamped = Math.min(600, Math.max(25, value));
    if (zoomRAF.current) { cancelAnimationFrame(zoomRAF.current); zoomRAF.current = null; }
    zoomCurrentRef.current = clamped;
    zoomTargetRef.current = clamped;
    setZoom(clamped);
  }
  useEffect(() => () => { if (zoomRAF.current) cancelAnimationFrame(zoomRAF.current); }, []);
  useEffect(() => {
    function stopPageZoom(event: WheelEvent) {
      if (!(event.ctrlKey || event.metaKey)) return;
      // Only preventDefault — stopPropagation would swallow the event before the
      // canvas stage's own zoom listener ever sees it.
      event.preventDefault();
    }
    document.addEventListener("wheel", stopPageZoom, { passive: false, capture: true });
    return () => document.removeEventListener("wheel", stopPageZoom, { capture: true } as EventListenerOptions);
  }, []);
  useEffect(() => {
    const node = wheelRef.current;
    if (!node) return;
    let last = 0;
    const onWheel = (event: WheelEvent) => {
      if (!(event.ctrlKey || event.metaKey)) return;
      event.preventDefault();
      event.stopPropagation();
      // Momentum-like zoom: bigger wheel flicks move more, rapid flicks accumulate.
      const now = performance.now();
      const dt = Math.min(48, now - last); last = now;
      const factor = Math.exp(-event.deltaY * 0.0016 * (dt / 16));
      smoothZoomTo(zoomTargetRef.current * factor);
    };
    node.addEventListener("wheel", onWheel, { passive: false });
    return () => node.removeEventListener("wheel", onWheel);
  }, []);
  const ctx: EditorContext = {
    doc, workspace, selected, selectedId, multiSelect, toggleMultiSelect, proActive, drawMode, brush,
    full: doc.layers.length >= MAX_LAYERS,
    tableStyleOpen, setTableStyleOpen, tableInsert, tableDelete, tableResize, tableDistribute, tableClear, selectTableCells: cells => { finishCellText(); setSelectedCells(cells); },
    setDrawMode: value => { setDrawMode(value); if (value) setFadeEditingId(null); }, setBrush,
    add: layer => {
      addLayer(layer);
      if (window.innerWidth <= 850) setShowPanel(false);
      if (layer.type === "text") setTimeout(() => startEditing(layer.id), 30);
    },
    addMany: addLayers,
    patch: patchLayer, remove: removeLayer, duplicate: duplicateLayer,
    select: id => { if (id !== editingRef.current) stopEditing(); if (selectedId && selectedId !== id) autoFitDeselectedText(selectedId); setMultiSelect([]); setSelectedId(id); setSelectedCells([]); setEditingCell(null); if (!id) setCropMode(false); },
    changeDoc: change, reorder, moveLayer, useTemplate, upload, uploads, notify,
    eraseMode, setEraseMode, eraseStrength, setEraseStrength, clearErase,
    tool, openPanel: id => { setTool(id as Tool); setShowPanel(true); },
    applyAiDesign: brief => { const next = buildAiDesign(brief); change(next); setTitle((brief.companyName || brief.name || `AI ${brief.type}`).trim()); setSelectedId(null); setEditingCell(null); setCellTextMode(false); setFadeEditingId(null); setCropMode(false); if (window.innerWidth <= 640) setShowPanel(false); notify("Your editable AI-assisted layout is ready. Make it yours!"); },
    styleClipboard, copyStyle, pasteStyle, fitImageToCanvas,
    fitText, fitTextUpdates, generateQR, previewQR,
    editingId, startEditing, stopEditing,
    selectedCells, editingCell, cellTextMode, beginCellText, finishCellText, formatCellText, changeCellTextCase, cropMode, setCropMode: value => { setCropMode(value); if (value) setFadeEditingId(null); },
    fadeEditingId,
    editOpacityFade: active => {
      if (active && selected && !selected.hidden && !selected.locked) {
        stopEditing(); setCropMode(false); setDrawMode(false); setEditingCell(null);
        setFadeEditingId(selected.id);
        if (window.innerWidth <= 850) setShowPanel(false);
      } else setFadeEditingId(null);
    },
    mergeSelected: () => { if (!selected || selected.type !== "table" || selectedCells.length < 2) return; patchLayer(selected.id, mergeCells(selected, selectedCells)); setSelectedCells([selectedCells[0]]); notify("Cells merged."); },
    splitSelected: () => { if (!selected || selected.type !== "table" || !selectedCells[0]) return; patchLayer(selected.id, splitCell(selected, selectedCells[0])); notify("Cell split."); },
    setFillImage: src => { if (selected) patchLayer(selected.id, { fillImage: src, fillGradient: undefined }); },
    setBackgroundImage: src => {
      const latest = current.current.doc;
      const full = (l: DesignLayer) => l.type === "image" && !l.qr && l.x === 0 && l.y === 0 && l.width === latest.width && l.height === latest.height;
      const layer: DesignLayer = { id: `bg-${Date.now().toString(36)}`, type: "image", x: 0, y: 0, width: latest.width, height: latest.height, fill: "transparent", src };
      const index = latest.layers.map(full).lastIndexOf(true);
      const layers = index >= 0 ? latest.layers.map((l, i) => i === index ? layer : l) : [layer, ...latest.layers];
      change({ ...latest, layers });
      notify("Background image applied.");
    },
    uploadBackgroundImage: async file => {
      try {
        const src = await readImage(file);
        ctx.setBackgroundImage(src);
      } catch (error) { notify((error as Error).message, true); }
    },
    uploadFillImage: async file => {
      if (!selected) return;
      try { const src = await readImage(file); patchLayer(selected.id, { fillImage: src, fillGradient: undefined }); notify("Image fill applied."); }
      catch (error) { notify((error as Error).message, true); }
    },
  };

  return <div ref={wheelRef} className="editor-shell" aria-label="Design editor" data-history={historyVersion} data-draw={drawMode ? "on" : "off"}>
    <header className="editor-topbar">
      <div className="editor-top-left">
        <button className="editor-home" disabled={closing} aria-label="Save and return home" onClick={async () => { setClosing(true); if (await save()) onClose(); setClosing(false); }}>{closing ? <Spinner size={18} /> : <ArrowLeft size={19} />}<span>Home</span></button>
        <span className="editor-separator" /><Logo compact />
        <input className="design-name-input" aria-label="Design name" value={title} maxLength={120} onChange={event => setTitle(event.target.value)} onBlur={() => { if (!title.trim()) setTitle("Untitled design"); }} />
      </div>
      <div className="editor-top-right">
        <ThemeToggle />
        <button
          className={`save-status save-icon-only status-${status}`}
          aria-label={status === "saving" ? "Saving design" : status === "saved" ? "All changes saved" : status === "error" ? "Retry saving design" : "Save design"}
          title={status === "saving" ? "Saving…" : status === "saved" ? "All changes saved" : status === "error" ? "Retry save" : "Save design (Ctrl/⌘ S)"}
          onClick={() => void saveToProjects()}
        >
          {status === "saving" ? <Spinner size={19} /> : <Save size={20} strokeWidth={2.2} />}
        </button>
        <DownloadMenu doc={doc} title={title} save={save} notify={notify} />
      </div>
    </header>

    <ContextBar ctx={ctx} onOpenPanel={id => ctx.openPanel(id)} textInputRef={textInputRef} />
    <div className="editor-body">
      <nav className="editor-rail" aria-label="Editor tools">
        {TOOLS.filter(item => item.id !== "effects").map(({ id, name, icon: Icon }) => <button key={id} className={tool === id && showPanel ? "active" : ""} aria-current={tool === id && showPanel} onClick={() => { if (id !== "draw" && drawMode) setDrawMode(false); if (tool === id) setShowPanel(!showPanel); else { setTool(id); setShowPanel(true); } }}><Icon size={22} strokeWidth={1.7} /><span>{name}</span></button>)}
        <div className="rail-bottom"><Logo compact /></div>
      </nav>

      {showPanel && <aside className="editor-panel" aria-label={`${activeTool.name} panel`}>
        <div className="editor-panel-heading"><h2>{activeTool.heading}</h2><button className="icon-button" aria-label="Close tools panel" onClick={() => setShowPanel(false)}><X size={16} /></button></div>
        {tool === "design" && <DesignPanel ctx={ctx} />}
        {tool === "template" && <TemplatePanel ctx={ctx} search={templateSearch} setSearch={setTemplateSearch} />}
        {tool === "ai" && <AiCreatePanel ctx={ctx} />}
        {tool === "text" && <TextPanel ctx={ctx} />}
        {tool === "icon" && <IconPanel ctx={ctx} />}
        {tool === "shape" && <ShapePanel ctx={ctx} />}
        {tool === "line" && <LinePanel ctx={ctx} />}
        {tool === "photo" && <PhotoPanel ctx={ctx} />}
        {tool === "background" && <BackgroundPanel ctx={ctx} />}
        {tool === "quote" && <QuotePanel ctx={ctx} />}
        {tool === "table" && <TablePanel ctx={ctx} />}
        {tool === "draw" && <DrawPanel ctx={ctx} />}
        {tool === "qr" && <QRPanel ctx={ctx} />}
        {tool === "uploads" && <UploadPanel ctx={ctx} fileRef={fileRef} />}
        {tool === "layer" && <LayerPanel ctx={ctx} />}
        {tool === "projects" && <ProjectsPanel
          projectId={project.id}
          title={title}
          status={status}
          savedTick={savedTick}
          onSaveNow={save}
          onSaveCopy={saveCopy}
          onOpen={async next => { await save(); if (onOpenProject) onOpenProject(next); else notify("Open this design from Your projects on the home page.", true); }}
          notify={notify}
        />}
        {tool === "effects" && <EffectsPanel ctx={ctx} />}
      </aside>}

      <div className="editor-center">
        <div className="canvas-toolbar">
          <div>
            <div className="canvas-history-buttons">
              <button className="icon-button" aria-label="Undo" title="Undo (Ctrl/⌘ Z)" disabled={!past.current.length} onClick={undo}><Undo2 size={17} /></button>
              <button className="icon-button" aria-label="Redo" title="Redo (Ctrl/⌘ Shift Z)" disabled={!future.current.length} onClick={redo}><Redo2 size={17} /></button>
            </div>
            <span className="canvas-toolbar-divider" />
            {/* Width / height / lock / unit for whichever element is selected (never the canvas). */}
            <SizeFields key={selected?.id ?? "none"} layer={selected} onPatch={updates => { if (selected) patchLayer(selected.id, updates); }} />
            {(fadeMode || drawMode) && <span className="canvas-toolbar-divider" />}
            {fadeMode && <span className="canvas-mode-label fade-mode-label">Opacity fade — drag the square, arrow or round handle</span>}
            {drawMode && !fadeMode && <span className="canvas-mode-label">Drawing mode — drag on your canvas</span>}
          </div>
          <div>
            {fadeMode && <button className="fade-toolbar-done" onClick={() => setFadeEditingId(null)}><Check size={15} />Done</button>}
            {eraseMode && <>
              <label className="erase-strength" title="Eraser brush diameter">
                <span>Size</span>
                <input type="range" min={4} max={200} step={2} value={eraseSize} aria-label="Eraser size" onChange={event => setEraseSize(Number(event.target.value))} />
                <small>{eraseSize}px</small>
              </label>
              <label className="erase-strength" title="How much each pass removes (opacity)">
                <span>Strength</span>
                <input type="range" min={10} max={100} step={5} value={Math.round(eraseStrength * 100)} aria-label="Eraser strength" onChange={event => setEraseStrength(Number(event.target.value) / 100)} />
                <small>{Math.round(eraseStrength * 100)}%</small>
              </label>
            </>}
            <button
              className={`icon-button ${eraseMode ? "selected" : ""}`}
              aria-label={eraseMode ? "Turn off the eraser" : "Erase parts of any element"}
              title="Eraser — drag over any element"
              aria-pressed={eraseMode}
              onClick={() => {
                const next = !eraseMode;
                setEraseMode(next);
                if (next) { setDrawMode(false); setFadeEditingId(null); }
              }}
            >
              <Eraser size={16} />
            </button>
            {(() => {
              const target = selected?.erased?.length ? selected : doc.layers.find(l => l.id === lastErasedId && l.erased?.length);
              return target ? <button className="icon-button" aria-label="Restore erased areas" title="Restore erased areas" onClick={() => clearErase(target.id)}><RotateCcw size={16} /></button> : null;
            })()}
            <button
              data-canvas-popover-trigger="opacity"
              className={`icon-button ${selected && (canvasPopover === "opacity" || selected.opacityFade) ? "selected" : ""}`}
              aria-label="Element opacity and fade"
              aria-expanded={selected ? canvasPopover === "opacity" : undefined}
              title={selected ? `Opacity & fade — ${Math.round((selected.opacity ?? 1) * 100)}%${selected.opacityFade ? " · fade on" : ""}` : "Select an element to set opacity & fade"}
              disabled={!selected}
              onClick={() => setCanvasPopover(canvasPopover === "opacity" ? null : "opacity")}
            >
              <TransparencyIcon size={16} />
            </button>
            <button
              data-canvas-popover-trigger="position"
              className={`icon-button ${selected && canvasPopover === "position" ? "selected" : ""}`}
              aria-label="Element position and size"
              aria-expanded={selected ? canvasPopover === "position" : undefined}
              title={selected ? "Position & size (X, Y, W, H)" : "Select an element to edit position & size"}
              disabled={!selected}
              onClick={() => setCanvasPopover(canvasPopover === "position" ? null : "position")}
            >
              <Move size={16} />
            </button>
            <button
              className={`icon-button ${formatPainterMode ? "selected" : ""}`}
              aria-label="Copy style (Format Painter)"
              title={formatPainterMode ? "Click another element to paste style (1-time)" : "Copy style (Format Painter)"}
              disabled={!selected && !formatPainterMode}
              onClick={() => {
                if (formatPainterMode) {
                  setFormatPainterMode(false);
                  setStyleClipboard(null);
                  notify("Copy style cancelled.");
                } else {
                  copyStyle();
                }
              }}
            >
              <PaintRoller size={16} />
            </button>
            <button
              className="icon-button"
              aria-label="Duplicate selected element"
              title={selected ? "Duplicate" : "Select an element to duplicate"}
              disabled={!selected}
              onClick={() => duplicateLayer(selected!.id)}
            >
              <Copy size={16} />
            </button>
            <button className={`icon-button ${drawMode ? "selected" : ""}`} aria-label={drawMode ? "Turn off the draw tool" : "Turn on the draw tool"} title="Draw tool" onClick={() => { setDrawMode(!drawMode); setEraseMode(false); setTool("draw"); setShowPanel(true); if (!drawMode) setSelectedId(null); }}><Pencil size={17} /></button>
            <button
              className={`icon-button ${selected?.locked ? "selected" : ""}`}
              aria-label={selected?.locked ? "Unlock selected element" : "Lock selected element"}
              aria-pressed={!!selected?.locked}
              title={selected ? (selected.locked ? "Unlock element" : "Lock element") : "Select an element to lock or unlock"}
              disabled={!selected}
              onClick={() => {
                if (!selected) return;
                patchLayer(selected.id, { locked: !selected.locked });
                notify(selected.locked ? "Element unlocked." : "Element locked — it can't be moved or resized.");
              }}
            >
              {selected?.locked ? <Lock size={16} /> : <Unlock size={16} />}
            </button>
            <button
              className="icon-button danger-hover"
              aria-label="Delete selected element"
              title={selected ? "Delete" : "Select an element to delete"}
              disabled={!selected}
              onClick={() => { if (selected) removeLayer(selected.id); }}
            >
              <Trash2 size={16} />
            </button>
          </div>
          {selected && canvasPopover && <CanvasToolbarPopover
            key={`${selected.id}-${canvasPopover}`}
            kind={canvasPopover}
            selected={selected}
            fadeEditingId={fadeEditingId}
            onPatch={updates => patchLayer(selected.id, updates)}
            onEditingChange={editing => {
              if (editing && selected && !selected.hidden && !selected.locked) {
                stopEditing(); setCropMode(false); setDrawMode(false); setEditingCell(null);
                setFadeEditingId(selected.id);
                if (window.innerWidth <= 850) setShowPanel(false);
              } else setFadeEditingId(null);
            }}
            onReorder={direction => reorder(selected.id, direction)}
            onDuplicate={() => duplicateLayer(selected.id)}
            onClose={() => setCanvasPopover(null)}
          />}
        </div>
        <div className="editor-stage" ref={stageRef} onClick={event => { if (event.target === event.currentTarget) { if (selectedId) autoFitDeselectedText(selectedId); setMultiSelect([]); setSelectedId(null); } }}>
          <div className="canvas-paper" ref={paperRef} style={{ width: doc.width * scale, height: doc.height * scale }}>
            <DesignCanvas document={doc} interactive drawMode={drawMode} selectedId={selectedId} onSelect={handleSelect} onMultiSelect={id => { if (id !== editingRef.current) stopEditing(); toggleMultiSelect(id); }} onDrillDown={handleDrillDown} onMarqueeSelect={handleMarqueeSelect} onLayerChange={handleLayerChange} onGuides={setGuides} onHover={setHoveredId} onTextActivate={startEditing} editingId={editingId} editingTableCell={editingCell && selected?.type === "table" ? { ...editingCell, layerId: selected.id } : null} onInteractionStart={beginInteraction} onInteractionEnd={endInteraction} />
            {guides.map((guide, index) => <span key={`${guide.axis}-${guide.at}-${index}`} className={`snap-guide guide-${guide.axis}`} style={guide.axis === "x" ? { left: guide.at * scale } : { top: guide.at * scale }} />)}
            {hovered && !drawMode && hovered.id !== selectedId && (() => {
              // Match the selection frame: an Effects-panel outline paints outside the layer box.
              const bleed = outlineBleed(hovered) * scale;
              return <div className={`hover-box ${hovered.locked ? "is-locked" : ""} ${hovered.hidden ? "is-hidden" : ""}`} style={{ left: hovered.x * scale - bleed, top: hovered.y * scale - bleed, width: hovered.width * scale + bleed * 2, height: hovered.height * scale + bleed * 2, transform: `rotate(${hovered.rotation || 0}deg)` }} />;
            })()}
            {multiAnchorCount >= 2 && <div className="multi-banner">
              <span>{multiAnchorCount} selected</span>
              <button type="button" onClick={() => groupSelection(multiSelect)} title="Group (Ctrl+G)">Group</button>
              <button type="button" onClick={() => { const gids = [...new Set(multiSelect.map(id => doc.layers.find(l => l.id === id)?.groupId).filter(Boolean))] as string[]; if (!gids.length) notify("No group selected.", true); else gids.forEach(ungroupGroup); }} title="Ungroup (Ctrl+U)">Ungroup</button>
            </div>}
            {multiAnchorCount >= 2 && !drawMode && !editingId && !fadeMode && !cropMode && <GroupSelectionBox layers={multiSelectedLayers} scale={scale} onTransform={applyGroupTransform} onStart={beginInteraction} onEnd={endInteraction} />}
            {editing && <TextEditorOverlay layer={editing} scale={scale} onChange={text => patchLayer(editing.id, { text })} onCommit={stopEditing} onLevels={levels => patchLayer(editing.id, { paraLevels: levels })} onPatch={updates => patchLayer(editing.id, updates)} />}
            {selected?.type === "table" && !selected.locked && !selected.hidden && !drawMode && !fadeMode && <TableOverlay layer={selected} scale={scale} selected={selectedCells} editing={editingCell} onSelect={(cell, additive) => { finishCellText(); setSelectedCells(current => { if (!additive || !current.length) return [cell]; const b = tableSelection(selected, [...current, cell]); return cellsInRect(b.r1, b.c1, b.r2, b.c2); }); }} onSelectRange={cells => { finishCellText(); setSelectedCells(cells); }} onEdit={beginCellText} onTracks={updates => patchLayer(selected.id, updates, false)} onStart={beginInteraction} onEnd={endInteraction} onCellText={(r, c, text) => patchLayer(selected.id, setCellText(current.current.doc.layers.find(l => l.id === selected.id) || selected, r, c, text), false)} onCommitEdit={finishCellText} onInsert={axis => tableInsert(axis, true)} />}
            {cropMode && selected?.type === "image" && !drawMode && <CropOverlay layer={selected} scale={scale} onChange={updates => patchLayer(selected.id, updates, false)} onStart={beginInteraction} onEnd={endInteraction} />}
            {selected && multiAnchorCount < 2 && !drawMode && !editingId && !fadeMode && !selected.hidden && !selected.locked && <SelectionBox layer={selected} scale={scale} onShiftClick={toggleMultiSelect} onChange={updates => {
              if (selected.type === "text" && !isCurvedText(selected) && selected.autoFit !== false && updates.fontSize !== undefined) {
                patchLayer(selected.id, { fontSize: updates.fontSize }, false);
                patchLayer(selected.id, fitTextUpdates(selected.id), false);
              } else patchLayer(selected.id, updates, false);
            }} onStart={beginInteraction} onEnd={endInteraction} />}
            {selected && selected.locked && !selected.hidden && !drawMode && multiAnchorCount < 2 && (() => {
              const bleed = outlineBleed(selected) * scale;
              return <div className="locked-box" style={{ left: selected.x * scale - bleed, top: selected.y * scale - bleed, width: selected.width * scale + bleed * 2, height: selected.height * scale + bleed * 2, transform: `rotate(${selected.rotation || 0}deg)` }}><span className="locked-badge"><Lock size={12} />Locked</span></div>;
            })()}
            {fadeMode && selected && <OpacityFadeOverlay key={selected.id} layer={selected} scale={scale} onChange={opacityFade => patchLayer(selected.id, { opacityFade }, false)} onStart={beginInteraction} onEnd={endInteraction} />}
            {eraseMode && !drawMode && <div className="draw-overlay eraser-mode" onPointerDown={startElementErase} onPointerMove={moveElementErase} onPointerUp={endElementErase} onPointerCancel={endElementErase} aria-label="Eraser surface" />}
            {drawMode && <div className={`draw-overlay ${brush.tool === "eraser" ? "eraser-mode" : ""}`} ref={overlayRef} onPointerDown={startStroke} onPointerMove={continueStroke} onPointerUp={endStroke} onPointerCancel={endStroke} aria-label="Drawing surface">
              {strokePreview && <svg className="draw-preview" viewBox={`0 0 ${doc.width} ${doc.height}`} preserveAspectRatio="none"><path d={strokePreview} fill="none" stroke={brush.color} strokeWidth={brush.size} strokeLinecap="round" strokeLinejoin="round" /></svg>}
            </div>}
          </div>
        </div>
        <footer className="editor-bottom">
          <span className="page-counter"><Layers size={15} />{doc.layers.length} / {MAX_LAYERS} elements</span>
          <span className="canvas-dimensions">{doc.width} × {doc.height} px</span>
          <div className="zoom-controls">
            <button aria-label="Zoom out" onClick={() => smoothZoomTo(zoomTargetRef.current * 0.85)}><Minus size={15} /></button>
            <RangeControl compact hideLabel label="Canvas zoom" min={25} max={600} value={Math.round(zoom)} unit="%" onChange={value => setZoomDirect(value)} />
            <button aria-label="Zoom in" onClick={() => smoothZoomTo(zoomTargetRef.current / 0.85)}><Plus size={15} /></button>
            <button className="zoom-value" title="Reset to fit" onClick={() => smoothZoomTo(100)}>{zoom === 100 ? "Fit" : `${Math.round(zoom)}%`}</button>
            <button aria-label="Fit canvas to screen" onClick={() => { smoothZoomTo(100); setShowPanel(false); }}><Maximize size={15} /></button>
          </div>
        </footer>
      </div>
    </div>

    {selected && multiAnchorCount < 2 && !selected.hidden && !drawMode && !editingId && !editingCell && !cellTextMode && !cropMode && !fadeMode && <ObjectToolbar key={selected.id} ctx={ctx} layer={selected} scale={scale} paperRef={paperRef} stageRef={stageRef} />}

    {replacement && <Modal title="A fresh starting point?" onClose={() => setReplacement(null)}>
      <p className="modal-intro">This replaces your canvas with “{replacement.title}”. Undo brings your current design right back.</p>
      <div className="replacement-preview" style={{ background: replacement.content.background }}><DesignCanvas document={replacement.content} /></div>
      <div className="modal-actions"><button className="secondary-button" onClick={() => setReplacement(null)}>Keep my design</button><button className="primary-button" onClick={() => applyTemplate(replacement)}><Sparkles size={16} />Use this template</button></div>
    </Modal>}

    <span className="sr-only" aria-live="polite">{drawMode ? "Drawing mode is on. Drag on the canvas to draw." : ""}</span>
  </div>;
}
