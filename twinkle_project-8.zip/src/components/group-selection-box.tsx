import { useRef, useState, type PointerEvent } from "react";
import { RotateCw } from "lucide-react";
import type { DesignLayer } from "@/lib/designs";
import { isCurvedText, resizeCurvedText } from "@/lib/text-curve";

interface Props {
  layers: DesignLayer[];
  scale: number;
  onTransform: (map: Record<string, Partial<DesignLayer>>) => void;
  onStart: () => void;
  onEnd: () => void;
}

const HANDLES = [
  { key: "nw", ax: -1, ay: -1, name: "top left", cursor: "nwse-resize" },
  { key: "n", ax: 0, ay: -1, name: "top", cursor: "ns-resize" },
  { key: "ne", ax: 1, ay: -1, name: "top right", cursor: "nesw-resize" },
  { key: "e", ax: 1, ay: 0, name: "right", cursor: "ew-resize" },
  { key: "se", ax: 1, ay: 1, name: "bottom right", cursor: "nwse-resize" },
  { key: "s", ax: 0, ay: 1, name: "bottom", cursor: "ns-resize" },
  { key: "sw", ax: -1, ay: 1, name: "bottom left", cursor: "nesw-resize" },
  { key: "w", ax: -1, ay: 0, name: "left", cursor: "ew-resize" },
] as const;

const MIN = 8;
const normAngle = (deg: number) => {
  let next = ((deg % 360) + 360) % 360;
  if (next > 180) next -= 360;
  return next;
};

export function groupBounds(layers: DesignLayer[]) {
  const minX = Math.min(...layers.map(l => l.x));
  const minY = Math.min(...layers.map(l => l.y));
  const maxX = Math.max(...layers.map(l => l.x + l.width));
  const maxY = Math.max(...layers.map(l => l.y + l.height));
  return { x: minX, y: minY, width: Math.max(MIN, maxX - minX), height: Math.max(MIN, maxY - minY) };
}

type DragState =
  | { mode: "move"; startX: number; startY: number; snapshot: DesignLayer[] }
  | { mode: "resize"; ax: number; ay: number; startX: number; startY: number; snapshot: DesignLayer[]; box: { x: number; y: number; width: number; height: number } }
  | { mode: "rotate"; centerX: number; centerY: number; startAngle: number; startRot: number; snapshot: DesignLayer[]; box: { x: number; y: number; width: number; height: number } };

/** One Canva-style frame around the whole multi-selection: move, scale and rotate together. */
export default function GroupSelectionBox({ layers, scale, onTransform, onStart, onEnd }: Props) {
  const boxRef = useRef<HTMLDivElement>(null);
  const state = useRef<DragState | null>(null);
  const [active, setActive] = useState<"move" | "resize" | "rotate" | null>(null);
  const [activeHandle, setActiveHandle] = useState<string | null>(null);
  const [live, setLive] = useState<{ width: number; height: number; rotation: number } | null>(null);

  const box = groupBounds(layers);
  const angle = 0;

  function beginMove(event: PointerEvent<HTMLElement>) {
    // Handles stop propagation; anything else on the frame starts a group move.
    if ((event.target as HTMLElement).closest("button")) return;
    event.preventDefault();
    event.stopPropagation();
    state.current = { mode: "move", startX: event.clientX, startY: event.clientY, snapshot: layers.map(l => ({ ...l })) };
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
    setActive("move");
    setActiveHandle(null);
    onStart();
  }

  function begin(event: PointerEvent<HTMLElement>, mode: "resize" | "rotate", handleKey: string, ax = 0, ay = 0) {
    event.preventDefault();
    event.stopPropagation();
    const rect = boxRef.current!.getBoundingClientRect();
    const snapshot = layers.map(l => ({ ...l }));
    if (mode === "rotate") {
      state.current = {
        mode, startX: 0, startY: 0,
        centerX: rect.left + rect.width / 2, centerY: rect.top + rect.height / 2,
        startAngle: Math.atan2(event.clientY - (rect.top + rect.height / 2), event.clientX - (rect.left + rect.width / 2)),
        startRot: 0, snapshot, box: { ...box },
      } as DragState;
    } else {
      state.current = { mode, ax, ay, startX: event.clientX, startY: event.clientY, snapshot, box: { ...box } };
    }
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
    setActive(mode);
    setActiveHandle(handleKey);
    setLive({ width: box.width, height: box.height, rotation: 0 });
    onStart();
  }

  function move(event: PointerEvent<HTMLElement>) {
    const drag = state.current;
    if (!drag) return;

    if (drag.mode === "move") {
      const dx = (event.clientX - drag.startX) / scale;
      const dy = (event.clientY - drag.startY) / scale;
      const map: Record<string, Partial<DesignLayer>> = {};
      for (const s of drag.snapshot) map[s.id] = { x: Math.round(s.x + dx), y: Math.round(s.y + dy) };
      onTransform(map);
      return;
    }

    if (drag.mode === "rotate") {
      const pointer = Math.atan2(event.clientY - drag.centerY, event.clientX - drag.centerX);
      let delta = (pointer - drag.startAngle) * 180 / Math.PI;
      delta = normAngle(delta);
      if (event.shiftKey) delta = Math.round(delta / 15) * 15;
      else for (const snap of [-180, -90, 0, 90, 180]) if (Math.abs(delta - snap) < 4) delta = snap;
      const rad = delta * Math.PI / 180;
      const cx = drag.box.x + drag.box.width / 2, cy = drag.box.y + drag.box.height / 2;
      const map: Record<string, Partial<DesignLayer>> = {};
      for (const s of drag.snapshot) {
        const scx = s.x + s.width / 2, scy = s.y + s.height / 2;
        const rx = scx - cx, ry = scy - cy;
        const ncx = cx + rx * Math.cos(rad) - ry * Math.sin(rad);
        const ncy = cy + rx * Math.sin(rad) + ry * Math.cos(rad);
        map[s.id] = { x: Math.round(ncx - s.width / 2), y: Math.round(ncy - s.height / 2), rotation: normAngle(Math.round((s.rotation || 0) + delta)) };
      }
      setLive({ width: drag.box.width, height: drag.box.height, rotation: Math.round(delta) });
      onTransform(map);
      return;
    }

    // Resize: scale every member inside the moving frame.
    const dx = (event.clientX - drag.startX) / scale;
    const dy = (event.clientY - drag.startY) / scale;
    const corner = drag.ax !== 0 && drag.ay !== 0;
    let newWidth = drag.ax ? Math.max(MIN, drag.box.width + dx * drag.ax) : drag.box.width;
    let newHeight = drag.ay ? Math.max(MIN, drag.box.height + dy * drag.ay) : drag.box.height;
    if (corner && !event.altKey) {
      // Canva-style: corners scale proportionally unless Alt forces free stretch.
      const sx = newWidth / drag.box.width, sy = newHeight / drag.box.height;
      const s = Math.abs(sx - 1) > Math.abs(sy - 1) ? sx : sy;
      newWidth = Math.max(MIN, drag.box.width * s);
      newHeight = Math.max(MIN, drag.box.height * s);
    }
    const sx = newWidth / drag.box.width, sy = newHeight / drag.box.height;
    const newX = drag.ax === 0 ? drag.box.x : drag.ax > 0 ? drag.box.x : drag.box.x + drag.box.width - newWidth;
    const newY = drag.ay === 0 ? drag.box.y : drag.ay > 0 ? drag.box.y : drag.box.y + drag.box.height - newHeight;
    const map: Record<string, Partial<DesignLayer>> = {};
    for (const s of drag.snapshot) {
      const rx = (s.x - drag.box.x) / drag.box.width, ry = (s.y - drag.box.y) / drag.box.height;
      const updates: Partial<DesignLayer> = {
        x: Math.round(newX + rx * newWidth),
        y: Math.round(newY + ry * newHeight),
        width: Math.max(MIN, Math.round(s.width * sx)),
        height: Math.max(MIN, Math.round(s.height * sy)),
      };
      if (isCurvedText(s)) {
        const factor = corner ? (sx + sy) / 2 : drag.ax ? sx : sy;
        Object.assign(updates, resizeCurvedText({ ...s, ...updates }, factor, drag.ax, drag.ay));
      } else {
        if (s.type === "text" && s.fontSize) updates.fontSize = Math.max(8, Math.min(1000, Math.round(s.fontSize * (corner ? (sx + sy) / 2 : drag.ax ? sx : sy))));
        if (s.type === "stroke" && s.strokeWidth) updates.strokeWidth = Math.max(1, Math.min(400, Math.round(s.strokeWidth * (corner ? (sx + sy) / 2 : sy))));
      }
      map[s.id] = updates;
    }
    setLive({ width: Math.round(newWidth), height: Math.round(newHeight), rotation: 0 });
    onTransform(map);
  }

  function finish(event: PointerEvent<HTMLElement>) {
    if (!state.current) return;
    (event.currentTarget as HTMLElement).releasePointerCapture?.(event.pointerId);
    state.current = null;
    setActive(null);
    setActiveHandle(null);
    setLive(null);
    onEnd();
  }

  const shownW = live ? live.width : Math.round(box.width);
  const shownH = live ? live.height : Math.round(box.height);
  const isDragging = active === "resize" || active === "rotate";

  return <div
    ref={boxRef}
    className={`selection-box group-selection-box ${active ? "is-active" : ""} ${isDragging ? "is-dragging" : ""}`}
    data-selection-box="true"
    style={{ left: box.x * scale, top: box.y * scale, width: box.width * scale, height: box.height * scale }}
    onPointerDown={beginMove}
    onPointerMove={move}
    onPointerUp={finish}
    onPointerCancel={finish}
  >
    <div className="selection-outline" />
    <span className="group-count-badge">{layers.length} selected</span>
    {HANDLES.map(handle => {
      const isThis = activeHandle === handle.key;
      const hide = isDragging && !isThis;
      return <button
        key={handle.key}
        type="button"
        className={`selection-handle handle-${handle.key} ${handle.ax === 0 || handle.ay === 0 ? "handle-edge" : "handle-corner"}${isThis ? " is-active-handle" : ""}${hide ? " is-hidden-handle" : ""}`}
        style={{ cursor: handle.cursor, left: `${(handle.ax + 1) * 50}%`, top: `${(handle.ay + 1) * 50}%` }}
        aria-label={`Resize group from ${handle.name}`}
        aria-hidden={hide || undefined}
        tabIndex={hide ? -1 : undefined}
        onPointerDown={event => begin(event, "resize", handle.key, handle.ax, handle.ay)}
        onPointerMove={move}
        onPointerUp={finish}
        onPointerCancel={finish}
      />;
    })}
    <button
      type="button"
      className={`selection-rotate${activeHandle === "rotate" ? " is-active-handle" : ""}${isDragging && activeHandle !== "rotate" ? " is-hidden-handle" : ""}`}
      aria-label="Rotate group"
      aria-hidden={isDragging && activeHandle !== "rotate" ? true : undefined}
      tabIndex={isDragging && activeHandle !== "rotate" ? -1 : undefined}
      style={{ cursor: active === "rotate" ? "grabbing" : "grab" }}
      onPointerDown={event => begin(event, "rotate", "rotate")}
      onPointerMove={move}
      onPointerUp={finish}
      onPointerCancel={finish}
    ><RotateCw size={13} /></button>
    {active && <span className="selection-readout">{active === "rotate" ? `${live?.rotation ?? 0}°` : `${shownW} × ${shownH}`}</span>}
  </div>;
}
