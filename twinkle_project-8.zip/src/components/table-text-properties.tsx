import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { AlignCenter, AlignLeft, AlignRight, ArrowDownToLine, ArrowLeft, ArrowUpDown, ArrowUpToLine, Bold, CaseSensitive, Check, ChevronDown, Italic, Strikethrough, Type, Underline, X } from "lucide-react";
import { FONTS, hexWithAlpha, type DesignLayer, type TextCase } from "@/lib/designs";
import { pxToPt, ptToPx, tableCellTextColor, tableCellTextStyle, tableSelection } from "@/lib/table";
import { NumericValue } from "@/components/range-control";
import RangeControl from "@/components/range-control";
import FillPicker from "@/components/fill-picker";
import type { EditorContext } from "@/components/editor-panels";
import { sidePopoverPlacement } from "@/lib/popover-placement";

const HORIZONTAL = [
  { key: "left" as const, label: "Left", Icon: AlignLeft },
  { key: "center" as const, label: "Center", Icon: AlignCenter },
  { key: "right" as const, label: "Right", Icon: AlignRight },
];
const VERTICAL = [
  { key: "top" as const, label: "Top", Icon: ArrowUpToLine },
  { key: "middle" as const, label: "Middle", Icon: AlignCenter },
  { key: "bottom" as const, label: "Bottom", Icon: ArrowDownToLine },
];

export default function TableTextProperties({ ctx }: { ctx: EditorContext }) {
  const layer = ctx.selected!;
  const cell = ctx.editingCell || ctx.selectedCells[0] || { r: 0, c: 0 };
  const text = tableCellTextStyle(layer, cell.r, cell.c), color = tableCellTextColor(layer, cell.r, cell.c);
  const selection = tableSelection(layer, ctx.selectedCells);
  const [menu, setMenu] = useState<"color" | "spacing" | "case" | "align" | null>(null);
  const [position, setPosition] = useState({ left: 10, top: 110 });
  const group = useRef<HTMLDivElement>(null);
  const Align = text.align === "center" ? AlignCenter : text.align === "right" ? AlignRight : AlignLeft;
  const colourLayer: DesignLayer = { id: `${layer.id}-${cell.r}-${cell.c}-text`, type: "text", x: 0, y: 0, width: 200, height: 60, fill: color === "transparent" ? "#000000" : color.slice(0, 7), fillAlpha: color.length === 9 ? parseInt(color.slice(7), 16) / 255 : color === "transparent" ? 0 : 1 };
  const hLabel = text.align === "center" ? "Center" : text.align === "right" ? "Right" : "Left";
  const vLabel = text.verticalAlign === "top" ? "Top" : text.verticalAlign === "bottom" ? "Bottom" : "Middle";
  useEffect(() => {
    if (!menu) return;
    function place() {
      const rect = group.current?.querySelector(`[data-cell-text-trigger="${menu}"]`)?.getBoundingClientRect();
      if (rect) {
        const width = menu === "align" ? 228 : 270;
        const height = menu === "color" ? 640 : menu === "align" ? 300 : 380;
        const { left, top } = sidePopoverPlacement(rect, { width, height });
        setPosition({ left, top });
      }
    }
    function outside(e: PointerEvent) { if (!(e.target as Element).closest("[data-cell-text-popover],[data-cell-text-trigger]")) setMenu(null); }
    function escape(e: KeyboardEvent) { if ((e.target as Element).matches?.('input[type="number"]')) return; if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); setMenu(null); } }
    place(); window.addEventListener("resize", place); document.addEventListener("scroll", place, true); document.addEventListener("pointerdown", outside, true); document.addEventListener("keydown", escape, true);
    return () => { window.removeEventListener("resize", place); document.removeEventListener("scroll", place, true); document.removeEventListener("pointerdown", outside, true); document.removeEventListener("keydown", escape, true); };
  }, [menu]);
  const toggle = (value: typeof menu) => setMenu(menu === value ? null : value);
  const titles = { color: "Cell text colour", spacing: "Cell text spacing", case: "Cell text case", align: "Text alignment" } as const;
  return <div ref={group} className="cell-text-properties" data-keep-cell-editing>
    <button className="context-button cell-text-back" aria-label="Back to table properties" onClick={ctx.finishCellText}><ArrowLeft size={14} />Table</button>
    <span className="context-chip cell-text-chip"><Type size={13} />Cell text<small>{ctx.selectedCells.length > 1 ? `${ctx.selectedCells.length} cells` : `R${cell.r + 1} · C${cell.c + 1}`}</small></span>
    <select className="text-font-select" aria-label="Font family" value={text.fontFamily} onChange={e => ctx.formatCellText({ fontFamily: e.target.value })}>{FONTS.map(font => <option value={font} key={font}>{font}</option>)}</select>
    <div className="text-point-size"><NumericValue label="Font size" value={pxToPt(text.fontSize)} min={6} max={750} step={.1} onCommit={v => ctx.formatCellText({ fontSize: ptToPx(v) })} /><small>pt</small></div>
    <button data-cell-text-trigger="color" className="text-fill-button" style={{ background: color }} aria-label="Cell text color" aria-expanded={menu === "color"} title="Cell text colour" onClick={() => toggle("color")} />
    <span className="context-divider" />
    <button className={`context-icon ${text.fontWeight >= 600 ? "active" : ""}`} aria-label="Bold text" aria-pressed={text.fontWeight >= 600} onClick={() => ctx.formatCellText({ fontWeight: text.fontWeight >= 600 ? 400 : 700 })}><Bold size={15} /></button>
    <button className={`context-icon ${text.italic ? "active" : ""}`} aria-label="Italic text" aria-pressed={text.italic} onClick={() => ctx.formatCellText({ italic: !text.italic })}><Italic size={15} /></button>
    <button className={`context-icon ${text.underline ? "active" : ""}`} aria-label="Underline text" aria-pressed={text.underline} onClick={() => ctx.formatCellText({ underline: !text.underline })}><Underline size={15} /></button>
    <button className={`context-icon ${text.strikethrough ? "active" : ""}`} aria-label="Strikethrough text" aria-pressed={text.strikethrough} onClick={() => ctx.formatCellText({ strikethrough: !text.strikethrough })}><Strikethrough size={15} /></button>
    <span className="context-divider" />
    <button data-cell-text-trigger="align" className={`text-alignment-select ${menu === "align" ? "active" : ""}`} aria-label="Text alignment" aria-expanded={menu === "align"} title="Horizontal and vertical alignment" onClick={() => toggle("align")}>
      <Align size={15} /><span>{hLabel} · {vLabel}</span><ChevronDown size={11} />
    </button>
    <button className="context-button" data-cell-text-trigger="spacing" aria-label="Text spacing" aria-expanded={menu === "spacing"} onClick={() => toggle("spacing")}><ArrowUpDown size={14} />{text.lineHeight.toFixed(2)}<ChevronDown size={11} /></button>
    <button className="context-button" data-cell-text-trigger="case" aria-label="Change text case" aria-expanded={menu === "case"} onClick={() => toggle("case")}><CaseSensitive size={16} /><ChevronDown size={11} /></button>
    <span className="cell-text-help">Formatting applies to {ctx.selectedCells.length > 1 ? "selected cells" : "this cell"} only.</span>
    <button className="context-button cell-text-done" onClick={ctx.finishCellText} aria-label="Finish cell text editing"><Check size={14} />Done</button>
    {menu && createPortal(<div className="context-popover fixed cell-text-popover" data-context-popover data-keep-cell-editing data-cell-text-popover style={{ left: position.left, top: position.top, width: menu === "align" ? 228 : 270, maxHeight: Math.max(170, window.innerHeight - position.top - 12) }}>
      <p className="context-popover-title">{titles[menu]}<small>R{selection.r1 + 1}–{selection.r2 + 1} · C{selection.c1 + 1}–{selection.c2 + 1}</small></p>
      <button type="button" className="popover-x" aria-label="Close cell text popover" onClick={() => setMenu(null)}><X size={15} /></button>
      {menu === "color" && <FillPicker layer={colourLayer} brandColors={ctx.workspace?.colors || []} allowImage={false} allowGradient={false} onUploadFill={() => {}} onPatch={patch => { if (patch.fill !== undefined || Object.hasOwn(patch, "fillAlpha")) ctx.formatCellText({ fill: hexWithAlpha(patch.fill ?? colourLayer.fill, patch.fillAlpha ?? 1) }); }} />}
      {menu === "spacing" && <><RangeControl label="Letter spacing" value={text.letterSpacing} min={-5} max={30} step={.5} unit="px" onChange={v => ctx.formatCellText({ letterSpacing: v })} /><RangeControl label="Line spacing" value={text.lineHeight} min={.8} max={3} step={.05} onChange={v => ctx.formatCellText({ lineHeight: v })} /><button className="secondary-button full-width" onClick={() => ctx.formatCellText({ letterSpacing: 0, lineHeight: 1.12 })}>Reset spacing</button></>}
      {menu === "case" && <div className="context-case-list">{([["upper", "UPPERCASE"], ["lower", "lowercase"], ["title", "Title Case"], ["sentence", "Sentence case"], ["toggle", "tOGGLE cASE"]] as [TextCase, string][]).map(([mode, label]) => <button key={mode} aria-label={`Apply ${label}`} onClick={() => ctx.changeCellTextCase(mode)}>{label}</button>)}</div>}
      {menu === "align" && <div className="cell-align-menu">
        <p className="cell-align-heading">Horizontal</p>
        <div className="cell-align-options" role="group" aria-label="Horizontal alignment">
          {HORIZONTAL.map(({ key, label, Icon }) => <button key={key} type="button" className={text.align === key ? "active" : ""} aria-pressed={text.align === key} onClick={() => ctx.formatCellText({ align: key })}><Icon size={15} />{label}</button>)}
        </div>
        <p className="cell-align-heading">Vertical</p>
        <div className="cell-align-options" role="group" aria-label="Vertical alignment">
          {VERTICAL.map(({ key, label, Icon }) => <button key={key} type="button" className={text.verticalAlign === key ? "active" : ""} aria-pressed={text.verticalAlign === key} onClick={() => ctx.formatCellText({ verticalAlign: key })}><Icon size={15} />{label}</button>)}
        </div>
      </div>}
    </div>, document.body)}
  </div>;
}
