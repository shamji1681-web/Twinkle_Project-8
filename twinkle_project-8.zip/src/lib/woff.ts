/**
 * Font container helpers for vector export.
 *
 * Uploaded fonts arrive as TTF, OTF, WOFF or WOFF2. A PDF can only embed raw sfnt
 * data (TTF/OTF), so WOFF — which is just a zlib-compressed sfnt — is unpacked back
 * to sfnt here with the browser's own inflate. WOFF2 (Brotli) cannot be unpacked in a
 * plain browser, so those uploads keep a high-resolution fallback instead.
 *
 * Also validates that a font carries a Unicode cmap: PDF writers need one to place
 * glyphs, and a font without it would silently drop the text.
 */

type Decompressor = new (format: string) => { readable: ReadableStream<Uint8Array> };

function inflate(data: Uint8Array): Promise<Uint8Array> {
  const Ctor = (globalThis as unknown as { DecompressionStream?: Decompressor }).DecompressionStream;
  if (!Ctor) return Promise.reject(new Error("woff"));
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const compressed = (new Blob([data as unknown as BlobPart]).stream() as any);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const stream = compressed.pipeThrough(new (Ctor as any)("deflate")) as any;
  return new Response(stream).arrayBuffer().then(buffer => new Uint8Array(buffer));
}

export function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index++) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

export function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let index = 0; index < bytes.length; index += chunk) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunk));
  }
  return btoa(binary);
}

const signature = (view: DataView, offset: number) => String.fromCharCode(view.getUint8(offset), view.getUint8(offset + 1), view.getUint8(offset + 2), view.getUint8(offset + 3));

/** Rebuilds the plain sfnt (TTF/OTF) inside a WOFF 1.0 container. */
export async function unpackWoff(data: Uint8Array): Promise<Uint8Array | null> {
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  if (view.byteLength < 44 || signature(view, 0) !== "wOFF") return null;
  const flavor = view.getUint32(4, false);
  const numTables = view.getUint16(12, false);
  const totalSize = view.getUint32(16, false);
  if (!numTables || numTables > 512 || totalSize < 12 + 16 * numTables) return null;

  const output = new Uint8Array(totalSize);
  const out = new DataView(output.buffer);
  out.setUint32(0, flavor, false);
  out.setUint16(4, numTables, false);
  const entrySelector = Math.floor(Math.log2(numTables));
  out.setUint16(6, Math.pow(2, entrySelector) * 16, false);
  out.setUint16(8, entrySelector, false);
  out.setUint16(10, numTables * 16 - Math.pow(2, entrySelector) * 16, false);

  let cursor = 12 + 16 * numTables;
  for (let index = 0; index < numTables; index++) {
    const entry = 44 + index * 20;
    if (entry + 20 > view.byteLength) return null;
    const offset = view.getUint32(entry + 4, false);
    const compressedLength = view.getUint32(entry + 8, false);
    const originalLength = view.getUint32(entry + 12, false);
    const checksum = view.getUint32(entry + 16, false);
    if (offset + compressedLength > view.byteLength || cursor + originalLength > totalSize) return null;
    const source = data.subarray(offset, offset + compressedLength);
    let table: Uint8Array;
    try {
      table = compressedLength < originalLength ? await inflate(source) : source.slice();
    } catch { return null; }
    if (table.length < originalLength) return null;

    const record = 12 + index * 16;
    out.setUint32(record, view.getUint32(entry, false), false); // tag
    out.setUint32(record + 4, checksum, false);
    out.setUint32(record + 8, cursor, false);
    out.setUint32(record + 12, originalLength, false);
    output.set(table.subarray(0, originalLength), cursor);
    cursor += originalLength + ((4 - (originalLength % 4)) % 4);
  }
  return output;
}

/** True when the sfnt carries a cmap subtable a PDF writer can use for text. */
export function hasUnicodeCmap(data: Uint8Array): boolean {
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  if (view.byteLength < 12) return false;
  const numTables = view.getUint16(4, false);
  let cmapOffset = -1;
  for (let index = 0; index < numTables; index++) {
    const record = 12 + index * 16;
    if (record + 16 > view.byteLength) return false;
    if (signature(view, record) === "cmap") { cmapOffset = view.getUint32(record + 8, false); break; }
  }
  if (cmapOffset < 0 || cmapOffset + 4 > view.byteLength) return false;
  const count = view.getUint16(cmapOffset + 2, false);
  for (let index = 0; index < count; index++) {
    const entry = cmapOffset + 4 + index * 8;
    if (entry + 8 > view.byteLength) return false;
    const platform = view.getUint16(entry, false);
    const encoding = view.getUint16(entry + 2, false);
    const subtable = cmapOffset + view.getUint32(entry + 4, false);
    if (subtable + 2 > view.byteLength) continue;
    const format = view.getUint16(subtable, false);
    const unicode = platform === 0 || (platform === 3 && (encoding === 1 || encoding === 10 || encoding === 3));
    if (unicode && (format === 0 || format === 4 || format === 6 || format === 12 || format === 13)) return true;
  }
  return false;
}

/**
 * Normalises any uploaded font container to embeddable sfnt base64, or null when the
 * container cannot be opened in the browser (WOFF2, corrupt files, symbol-only fonts).
 */
export async function embeddableFontBase64(dataUrl: string): Promise<string | null> {
  const comma = dataUrl.indexOf(",");
  if (comma < 0 || !/base64/i.test(dataUrl.slice(0, comma))) return null;
  let bytes: Uint8Array;
  try { bytes = base64ToBytes(dataUrl.slice(comma + 1)); } catch { return null; }
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes.byteLength < 12) return null;
  const head = signature(view, 0);
  let sfnt: Uint8Array | null = null;
  if (head === "wOFF") sfnt = await unpackWoff(bytes);
  else if (head === "OTTO" || head === "true" || head === "ttcf" || view.getUint32(0, false) === 0x00010000) sfnt = bytes;
  else return null; // "wOF2" (WOFF2) and anything unrecognised
  if (!sfnt || !hasUnicodeCmap(sfnt)) return null;
  return bytesToBase64(sfnt);
}
