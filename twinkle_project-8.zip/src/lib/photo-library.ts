/**
 * Unlimited background / stock photo library.
 *
 * Photos come from Lorem Picsum (https://picsum.photos): free Unsplash photography served with open CORS,
 * no API key. The catalogue (~1000 photos) is loaded once and then streamed in endlessly:
 * once every photo has been shown, the same photos come round again in fresh looks
 * (soft-focus at different strengths, black & white, …) so the gallery never runs out.
 *
 * Designs may only store bundled paths or `data:image/...` URLs, so a picked photo is always downloaded
 * and stored as a data URL. That also keeps exports, "Remove BG" and offline editing working.
 */

export type PhotoMode = "all" | "soft" | "bw";

export const PHOTO_MODES: { key: PhotoMode; label: string }[] = [
  { key: "all", label: "All photos" },
  { key: "soft", label: "Soft focus" },
  { key: "bw", label: "Black & white" },
];

export interface LibraryPhoto {
  /** Unique across the endless stream (id + look). */
  key: string;
  id: string;
  author: string;
  /** Original size of the source photo. */
  width: number;
  height: number;
  /** Look applied by the image host, e.g. "?blur=4&grayscale" (empty for the original). */
  query: string;
  thumb: string;
}

interface CatalogEntry { id: string; author: string; width: number; height: number }

const HOST = "https://picsum.photos";
const PAGE_SIZE = 100;
const MAX_PAGES = 12;
const SOFT_LEVELS = [2, 4, 6, 3, 8, 5, 10, 1, 7, 9];

let catalog: CatalogEntry[] | null = null;
let catalogLoading: Promise<CatalogEntry[]> | null = null;

/** Small deterministic shuffle so neighbours are not all from the same photographer/series. */
function shuffled<T>(items: T[], seed = 20240607): T[] {
  const list = items.slice();
  let state = seed >>> 0;
  const random = () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  for (let i = list.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [list[i], list[j]] = [list[j], list[i]];
  }
  return list;
}

async function fetchPage(page: number): Promise<CatalogEntry[]> {
  const response = await fetch(`${HOST}/v2/list?page=${page}&limit=${PAGE_SIZE}`);
  if (!response.ok) throw new Error(`Photo list failed (${response.status})`);
  const data = await response.json() as { id: string; author?: string; width: number; height: number }[];
  return data
    .filter(item => item && item.id !== undefined && item.width > 0 && item.height > 0)
    .map(item => ({ id: String(item.id), author: item.author || "Unsplash", width: item.width, height: item.height }));
}

function loadCatalog(): Promise<CatalogEntry[]> {
  if (catalog) return Promise.resolve(catalog);
  if (!catalogLoading) {
    catalogLoading = (async () => {
      const results = await Promise.allSettled(Array.from({ length: MAX_PAGES }, (_, i) => fetchPage(i + 1)));
      const first = results[0];
      if (first.status !== "fulfilled" || !first.value.length) throw new Error("The photo library could not be reached. Check your connection and try again.");
      const seen = new Set<string>();
      const all: CatalogEntry[] = [];
      for (const result of results) {
        if (result.status !== "fulfilled") continue;
        for (const item of result.value) if (!seen.has(item.id)) { seen.add(item.id); all.push(item); }
      }
      catalog = shuffled(all);
      return catalog;
    })().finally(() => { catalogLoading = null; });
  }
  return catalogLoading;
}

/** The "look" applied to a photo on a given lap through the catalogue. */
function variantParams(mode: PhotoMode, round: number): string[] {
  const level = (n: number) => SOFT_LEVELS[((n % SOFT_LEVELS.length) + SOFT_LEVELS.length) % SOFT_LEVELS.length];
  if (mode === "soft") return [`blur=${level(round)}`, ...(Math.floor(round / SOFT_LEVELS.length) % 2 ? ["grayscale"] : [])];
  if (mode === "bw") return ["grayscale", ...(round > 0 ? [`blur=${level(round - 1)}`] : [])];
  if (round === 0) return [];
  return [`blur=${level(round - 1)}`, ...(Math.floor((round - 1) / SOFT_LEVELS.length) % 2 ? ["grayscale"] : [])];
}

const toQuery = (params: string[]) => (params.length ? `?${params.join("&")}` : "");

/** Returns `count` photos of the endless stream starting at position `from`. Never runs out. */
export async function loadPhotoBatch(mode: PhotoMode, from: number, count: number): Promise<LibraryPhoto[]> {
  const list = await loadCatalog();
  const total = list.length;
  const photos: LibraryPhoto[] = [];
  for (let k = from; k < from + count; k++) {
    const round = Math.floor(k / total);
    const entry = list[((k % total) + round * 211) % total];
    const query = toQuery(variantParams(mode, round));
    photos.push({
      key: `${mode}-${entry.id}-${round}`,
      id: entry.id,
      author: entry.author,
      width: entry.width,
      height: entry.height,
      query,
      thumb: `${HOST}/id/${entry.id}/360/240.jpg${query}`,
    });
  }
  return photos;
}

/** Longest side capped so a saved design stays small; the aspect ratio is kept. */
export function fitPhotoSize(width: number, height: number, maxSide = 1600) {
  const scale = Math.min(1, maxSide / Math.max(width, height, 1));
  return { width: Math.max(16, Math.round(width * scale)), height: Math.max(16, Math.round(height * scale)) };
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("The photo could not be read."));
    reader.readAsDataURL(blob);
  });
}

/** Downloads a library photo cropped to exactly `width` × `height` and returns it as a data URL. */
export async function downloadPhoto(photo: LibraryPhoto, width: number, height: number): Promise<string> {
  const size = fitPhotoSize(width, height, 1800);
  const url = `${HOST}/id/${photo.id}/${size.width}/${size.height}.jpg${photo.query}`;
  let response: Response;
  try { response = await fetch(url); }
  catch { throw new Error("Couldn't download that photo. Check your connection and try again."); }
  if (!response.ok) throw new Error("That photo isn't available right now. Please try another one.");
  const blob = await response.blob();
  if (!/^image\/(jpeg|png|webp)$/.test(blob.type)) throw new Error("That photo isn't available right now. Please try another one.");
  const dataUrl = await blobToDataUrl(blob);
  if (dataUrl.length > 3_800_000) throw new Error("That photo is too large to save. Please try another one.");
  return dataUrl.replace(/^data:image\/jpg;/, "data:image/jpeg;");
}
