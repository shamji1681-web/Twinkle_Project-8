import type { DesignDocument, DesignLayer } from "@/lib/designs";

export interface Glyph { char: string; x: number; y: number; rotation: number }
export interface CurveBounds { minX: number; minY: number; width: number; height: number }
interface Metrics { advance: number; left: number; right: number; ascent: number; descent: number }
let context: CanvasRenderingContext2D | null = null;
const cache = new Map<string, { glyphs: Glyph[]; bounds: CurveBounds }>();
export const isCurvedText = (layer: DesignLayer) => layer.type === "text" && Math.abs(layer.curve || 0) >= 4;

function measurer(layer: DesignLayer) {
  if (!context && typeof document !== "undefined") context = document.createElement("canvas").getContext("2d");
  if (context) {
    context.font = `${layer.italic ? "italic " : ""}${layer.fontWeight || 400} ${layer.fontSize || 40}px "${layer.fontFamily || "Arial"}"`;
    context.textAlign = "left";
    context.textBaseline = "alphabetic";
  }
  return context;
}
function glyphMetrics(target: CanvasRenderingContext2D | null, char: string, size: number): Metrics {
  const m = target?.measureText(char);
  const advance = m?.width ?? (char === " " ? .28 : .58) * size;
  return {
    advance,
    left: Math.min(-advance / 2, -advance / 2 - (m?.actualBoundingBoxLeft || 0)),
    right: Math.max(advance / 2, -advance / 2 + (m?.actualBoundingBoxRight || advance)),
    ascent: Math.max(m?.fontBoundingBoxAscent || size * .95, m?.actualBoundingBoxAscent || 0),
    descent: Math.max(m?.fontBoundingBoxDescent || size * .26, m?.actualBoundingBoxDescent || 0, layerDecorationDescent(size)),
  };
}
function layerDecorationDescent(size: number) { return size * .2; }

/** One deterministic glyph layout is used by drawing, selection, resize and hit-testing. */
export function curveLayout(layer: DesignLayer) {
  const size = layer.fontSize || 40;
  const key = JSON.stringify([layer.text, size, layer.fontFamily, layer.fontWeight, layer.italic, layer.curve, layer.letterSpacing]);
  const target = measurer(layer);
  const existing = target && cache.get(key);
  if (existing) return existing;
  const chars = Array.from((layer.text || "").replace(/\r?\n/g, " "));
  if (!chars.length) return { glyphs: [] as Glyph[], bounds: { minX: 0, minY: 0, width: Math.ceil(size), height: Math.ceil(size * 1.2) } };
  const metrics = chars.map(c => glyphMetrics(target, c, size));
  const advances = metrics.map((m, i) => Math.max(size * .05, m.advance + (i < chars.length - 1 ? (layer.letterSpacing || 0) : 0)));
  const total = advances.reduce((a, b) => a + b, 0);
  const curve = Math.max(-360, Math.min(360, layer.curve || 0));
  const span = Math.max(.00001, Math.abs(curve) * Math.PI / 180), radius = total / span;
  const upper = curve >= 0;
  let distance = 0, minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  const glyphs = chars.map((char, i) => {
    const theta = -span / 2 + (distance + advances[i] / 2) / total * span;
    const glyph = { char, x: Math.sin(theta) * radius, y: (radius - Math.cos(theta) * radius) * (upper ? 1 : -1), rotation: theta * 180 / Math.PI * (upper ? 1 : -1) };
    const m = metrics[i], a = glyph.rotation * Math.PI / 180, cos = Math.cos(a), sin = Math.sin(a);
    const pad = Math.max(1, size * .02);
    for (const [x, y] of [[m.left - pad, -m.ascent - pad], [m.right + pad, -m.ascent - pad], [m.right + pad, m.descent + pad], [m.left - pad, m.descent + pad]]) {
      const px = glyph.x + x * cos - y * sin, py = glyph.y + x * sin + y * cos;
      minX = Math.min(minX, px); maxX = Math.max(maxX, px); minY = Math.min(minY, py); maxY = Math.max(maxY, py);
    }
    distance += advances[i];
    return glyph;
  });
  const bounds = { minX: Math.floor(minX), minY: Math.floor(minY), width: Math.ceil(maxX) - Math.floor(minX), height: Math.ceil(maxY) - Math.floor(minY) };
  const result = { glyphs, bounds };
  if (target) { if (cache.size > 256) cache.clear(); cache.set(key, result); }
  return result;
}
export const curvedGlyphs = (layer: DesignLayer): Glyph[] => curveLayout(layer).glyphs;
export const curveBounds = (layer: DesignLayer, _glyphs?: Glyph[]): CurveBounds => curveLayout(layer).bounds;
export const curvedHeight = (layer: DesignLayer) => curveBounds(layer).height;
export function fitCurvedBox(layer: DesignLayer): Partial<DesignLayer> {
  const { width, height } = curveBounds(layer);
  return { width, height, x: layer.x + (layer.width - width) / 2, y: layer.y + (layer.height - height) / 2, autoFit: false };
}

/** Repairs stale saved rectangles without moving the actual arc's world-space origin. */
export function normalizeCurvedLayer(layer: DesignLayer): DesignLayer {
  if (!isCurvedText(layer)) return layer;
  const { width, height } = curveBounds(layer);
  if (Math.abs(layer.width - width) < .01 && Math.abs(layer.height - height) < .01 && layer.autoFit === false) return layer;
  const dx = (layer.width - width) / 2, dy = (layer.height - height) / 2, a = (layer.rotation || 0) * Math.PI / 180;
  return { ...layer, width, height, x: layer.x + dx - (dx * Math.cos(a) - dy * Math.sin(a)), y: layer.y + dy - (dx * Math.sin(a) + dy * Math.cos(a)), autoFit: false };
}
export function normalizeCurvedDocument(doc: DesignDocument): DesignDocument {
  let changed = false;
  const layers = doc.layers.map(layer => { const next = normalizeCurvedLayer(layer); if (next !== layer) changed = true; return next; });
  return changed ? { ...doc, layers } : doc;
}

/** Resizes the complete arc proportionally, keeping the opposite handle anchored. */
export function resizeCurvedText(source: DesignLayer, factor: number, ax: number, ay: number): Partial<DesignLayer> {
  const fontSize = Math.round(Math.max(8, Math.min(1000, (source.fontSize || 40) * factor)) * 100) / 100;
  const ratio = fontSize / (source.fontSize || 40);
  const letterSpacing = source.letterSpacing !== undefined ? source.letterSpacing * ratio : undefined;
  const { width, height } = curveBounds({ ...source, fontSize, letterSpacing });
  const dx = -ax * (source.width - width) / 2, dy = -ay * (source.height - height) / 2, a = (source.rotation || 0) * Math.PI / 180;
  return { fontSize, ...(letterSpacing !== undefined ? { letterSpacing } : {}), width, height, x: source.x + source.width / 2 + dx * Math.cos(a) - dy * Math.sin(a) - width / 2, y: source.y + source.height / 2 + dx * Math.sin(a) + dy * Math.cos(a) - height / 2, autoFit: false };
}
