/**
 * Browser-only replacement for the original Next.js API routes.
 * The workspace and all designs live in localStorage, so the app runs fully client-side
 * with no database. Every route mirrors the original validation rules and error messages.
 */
import { isValidDocument, type DesignDocument, type DesignProject, type Workspace } from "@/lib/designs";
import { normalizeQRSettings } from "@/lib/qr";
import { renderQrPng } from "@/lib/qr-render";
import { resolveAsset } from "@/lib/asset-map";
import { removeBackgroundInBrowser } from "@/lib/remove-background";

const WORKSPACE_KEY = "creato-workspace-v1";
const DESIGNS_KEY = "creato-designs-v1";

export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 400) { super(message); this.status = status; }
}

const uuid = () => {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === "x" ? r : (r & 0x3) | 0x8).toString(16); });
};

function read<T>(key: string): T | null {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : null; } catch { return null; }
}

function write(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)); }
  catch { throw new ApiError("Your browser storage is full. Delete a few designs from Trash or remove large uploaded images, then try again.", 507); }
}

function defaultWorkspace(): Workspace {
  return { id: uuid(), name: "Alex Morgan", brandName: "My creative studio", colors: ["#7952e9", "#d8cbfa", "#f8cbd7", "#064e48", "#f7f4ec"], logo: null, trialStartedAt: null };
}

function getWorkspace(): Workspace {
  const existing = read<Workspace>(WORKSPACE_KEY);
  if (existing && typeof existing.id === "string") return existing;
  const workspace = defaultWorkspace();
  write(WORKSPACE_KEY, workspace);
  // A fresh workspace starts with no projects — a design only appears after the
  // user actually saves it, so the Projects panel never shows prefilled templates.
  write(DESIGNS_KEY, []);
  return workspace;
}

function getDesigns(): DesignProject[] {
  getWorkspace();
  const list = read<DesignProject[]>(DESIGNS_KEY);
  return Array.isArray(list) ? list : [];
}

const byRecent = (a: DesignProject, b: DesignProject) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();

// ---- Route handlers -------------------------------------------------------------------------

function workspaceGet() {
  const workspace = getWorkspace();
  return { workspace, designs: getDesigns().sort(byRecent) };
}

function workspacePatch(body: Record<string, unknown>) {
  const workspace = getWorkspace();
  const updates: Partial<Workspace> = {};
  if (typeof body.name === "string") {
    if (!body.name.trim() || body.name.length > 80) throw new ApiError("Please enter a name under 80 characters.");
    updates.name = body.name.trim();
  }
  if (typeof body.brandName === "string") updates.brandName = body.brandName.trim().slice(0, 100) || "My creative studio";
  if (body.colors !== undefined) {
    if (!Array.isArray(body.colors) || body.colors.length > 12 || !body.colors.every((c: unknown) => typeof c === "string" && /^#[0-9a-f]{6}$/i.test(c))) throw new ApiError("Choose up to 12 valid brand colors.");
    updates.colors = body.colors as string[];
  }
  if (body.logo !== undefined) {
    if (body.logo !== null && (typeof body.logo !== "string" || body.logo.length > 4_000_000 || !/^data:image\/(png|jpeg|webp);base64,/.test(body.logo))) throw new ApiError("Please choose a PNG, JPEG, or WebP image under 3 MB.");
    updates.logo = body.logo as string | null;
  }
  if (body.startTrial === true && !workspace.trialStartedAt) updates.trialStartedAt = new Date().toISOString();
  if (Object.keys(updates).length === 0) return workspace;
  const updated = { ...workspace, ...updates };
  write(WORKSPACE_KEY, updated);
  return updated;
}

function designsPost(body: Record<string, unknown>): DesignProject {
  if (typeof body.title !== "string" || !body.title.trim() || body.title.length > 120 || !isValidDocument(body.content)) throw new ApiError("Please provide a title and a valid design.");
  const list = getDesigns();
  const stamp = new Date().toISOString();
  const created: DesignProject = { id: uuid(), title: body.title.trim(), category: typeof body.category === "string" ? body.category.slice(0, 50) : "Custom design", content: body.content as DesignDocument, starred: false, trashed: false, createdAt: stamp, updatedAt: stamp };
  write(DESIGNS_KEY, [created, ...list]);
  return created;
}

function designGet(id: string) {
  const design = getDesigns().find(d => d.id === id);
  if (!design) throw new ApiError("Design not found.", 404);
  return design;
}

function designPatch(id: string, body: Record<string, unknown>) {
  const list = getDesigns();
  const index = list.findIndex(d => d.id === id);
  if (index === -1) throw new ApiError("Design not found.", 404);
  const updates: Partial<DesignProject> = { updatedAt: new Date().toISOString() };
  if (body.title !== undefined) {
    if (typeof body.title !== "string" || !body.title.trim() || body.title.length > 120) throw new ApiError("Add a title between 1 and 120 characters.");
    updates.title = body.title.trim();
  }
  if (body.content !== undefined) {
    if (!isValidDocument(body.content)) throw new ApiError("This design contains an invalid element.");
    updates.content = body.content as DesignDocument;
  }
  if (typeof body.starred === "boolean") updates.starred = body.starred;
  if (typeof body.trashed === "boolean") updates.trashed = body.trashed;
  const updated = { ...list[index], ...updates };
  list[index] = updated;
  write(DESIGNS_KEY, list);
  return updated;
}

function designDelete(id: string) {
  const list = getDesigns();
  const target = list.find(d => d.id === id);
  if (!target || !target.trashed) throw new ApiError("Only designs in Trash can be permanently deleted.", 404);
  write(DESIGNS_KEY, list.filter(d => d.id !== id));
  return { success: true };
}

async function qrPost(body: Record<string, unknown>) {
  const settings = normalizeQRSettings(body.settings ?? body);
  if (settings.text.length < 2) throw new ApiError("Enter a link or message of at least 2 characters.");
  const workspace = getWorkspace();
  const dataUrl = await renderQrPng(settings.text, settings, settings.customLogo || (settings.logo ? workspace.logo : null));
  if (dataUrl.length > 3_500_000) throw new ApiError("That QR code is too large to store. Try a shorter link.");
  return { dataUrl, settings };
}

async function removeBackgroundPost(body: Record<string, unknown>) {
  const src = typeof body.src === "string" ? body.src : "";
  if (!src || src.length > 4_000_000) throw new ApiError("Choose an image under 3 MB to remove its background.");
  const dataUrl = await removeBackgroundInBrowser(resolveAsset(src));
  if (dataUrl.length > 4_000_000) throw new ApiError("The result is too large to store. Try a smaller image.");
  return { dataUrl };
}

// ---- Router --------------------------------------------------------------------------------

export async function localApi<T>(url: string, options?: RequestInit): Promise<T> {
  const method = (options?.method || "GET").toUpperCase();
  const body: Record<string, unknown> = typeof options?.body === "string" && options.body ? JSON.parse(options.body) : {};
  const path = url.split("?")[0].replace(/\/+$/, "");
  // A tiny delay keeps loading states visible and mirrors real network behaviour.
  await new Promise(resolve => setTimeout(resolve, 60));

  try {
    if (path === "/api/workspace" && method === "GET") return workspaceGet() as T;
    if (path === "/api/workspace" && method === "PATCH") return workspacePatch(body) as T;
    if (path === "/api/designs" && method === "GET") return getDesigns().sort(byRecent) as T;
    if (path === "/api/designs" && method === "POST") return designsPost(body) as T;
    const design = /^\/api\/designs\/([^/]+)$/.exec(path);
    if (design) {
      const id = decodeURIComponent(design[1]);
      if (method === "GET") return designGet(id) as T;
      if (method === "PATCH") return designPatch(id, body) as T;
      if (method === "DELETE") return designDelete(id) as T;
    }
    if (path === "/api/qr" && method === "POST") return (await qrPost(body)) as T;
    if (path === "/api/remove-background" && method === "POST") return (await removeBackgroundPost(body)) as T;
    if (path === "/api/health") return { ok: true } as T;
    throw new ApiError("Not found.", 404);
  } catch (error) {
    if (error instanceof ApiError) throw error;
    console.error("Creato local API:", error);
    throw new ApiError(path === "/api/qr" ? "We couldn't create that QR code. Please try again." : path === "/api/remove-background" ? (error as Error).message || "We couldn't remove that background. Please try again." : "We couldn't save that change. Please try again.", 500);
  }
}
